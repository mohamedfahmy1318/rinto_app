<?php
$pageTitle = 'تسجيل الدخول';
require_once __DIR__ . '/config.php';

// Handle login
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = $_POST['phone'] ?? '';
    $password = $_POST['password'] ?? '';
    
    $response = apiCall('auth/login', 'POST', [
        'login' => $phone,
        'password' => $password
    ]);
    
    if ($response['success'] ?? false) {
        $_SESSION['user'] = $response['data']['user'];
        $_SESSION['token'] = $response['data']['token'];
        
        // Redirect to original page or home
        $redirect = $_GET['redirect'] ?? $_POST['redirect'] ?? '';
        if ($redirect && !str_contains($redirect, '://')) {
            header('Location: ' . SITE_URL . '/' . $redirect);
        } else {
            header('Location: ' . SITE_URL);
        }
        exit;
    } else {
        $error = $response['message'] ?? 'فشل تسجيل الدخول';
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="auth-page py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="auth-card">
                    <div class="text-center mb-4">
                        <i class="bi bi-house-heart-fill auth-icon"></i>
                        <h2>تسجيل الدخول</h2>
                        <p class="text-muted">سجّل دخولك للمتابعة</p>
                    </div>
                    
                    <?php if ($error): ?>
                    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($_GET['msg']) && $_GET['msg'] === 'relogin'): ?>
                    <div class="alert alert-info">يرجى تسجيل الدخول مرة أخرى</div>
                    <?php endif; ?>
                    
                    <form method="POST" action="">
                        <?php if (isset($_GET['redirect'])): ?>
                        <input type="hidden" name="redirect" value="<?= htmlspecialchars($_GET['redirect']) ?>">
                        <?php endif; ?>
                        <div class="mb-3">
                            <label class="form-label">رقم الهاتف</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-phone"></i></span>
                                <input type="tel" name="phone" class="form-control" dir="ltr" placeholder="+972501234567" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">كلمة المرور</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-lock"></i></span>
                                <input type="password" name="password" class="form-control" required>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="remember">
                                <label class="form-check-label" for="remember">تذكرني</label>
                            </div>
                            <a href="forgot-password.php">نسيت كلمة المرور؟</a>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100 btn-lg mb-3">
                            <i class="bi bi-box-arrow-in-left me-2"></i>تسجيل الدخول
                        </button>
                        
                        <p class="text-center mb-0">
                            ليس لديك حساب؟ <a href="register.php">إنشاء حساب</a>
                        </p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
