<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/translations.php';

// Force login
if (!isset($_SESSION['user']) || !isset($_SESSION['token'])) {
    header('Location: login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit;
}

$user = $_SESSION['user'];
$planId = $_GET['plan_id'] ?? null;
$listingType = $_GET['listing_type'] ?? null;
$listingId = $_GET['listing_id'] ?? null;

if (!$planId) {
    header('Location: packages.php');
    exit;
}

// Get plan details
$planResponse = apiCall("plans/$planId");
$plan = $planResponse['data'] ?? null;

if (!$plan) {
    header('Location: packages.php');
    exit;
}

$error = '';
$success = false;

$pendingTransfer = false;

// Handle payment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pay'])) {
    $paymentMethod = $_POST['payment_method'] ?? 'test';
    
    $paymentData = [
        'plan_id' => $planId,
        'payment_method' => $paymentMethod,
        'transaction_id' => strtoupper($paymentMethod) . '_' . time() . '_' . rand(1000, 9999)
    ];
    
    // For bank transfer, set status to pending
    if ($paymentMethod === 'bank_transfer') {
        $paymentData['status'] = 'pending_verification';
        $paymentData['sender_name'] = $_POST['sender_name'] ?? '';
        $paymentData['transfer_date'] = $_POST['transfer_date'] ?? date('Y-m-d');
        $paymentData['transfer_reference'] = $_POST['transfer_reference'] ?? '';
    }
    
    // If there's a pending listing, include it
    if ($listingType && $listingId) {
        $paymentData['listing_type'] = $listingType;
        $paymentData['listing_id'] = $listingId;
    }
    
    $response = apiCall('subscriptions/purchase', 'POST', $paymentData, $_SESSION['token']);
    
    if ($response['success'] ?? false) {
        if ($paymentMethod === 'bank_transfer') {
            $pendingTransfer = true;
        } else {
            $success = true;
        }
    } else {
        $error = $response['message'] ?? ($lang === 'he' ? 'שגיאה בתשלום' : 'خطأ في عملية الدفع');
    }
}

// Bank account details (configured by admin)
$bankDetails = [
    'bank_name' => 'بنك فلسطين',
    'account_name' => 'RentoGo للخدمات',
    'account_number' => '1234567890',
    'iban' => 'PS00PALS000000001234567890',
    'branch' => 'الفرع الرئيسي'
];

$pageTitle = $lang === 'he' ? 'השלמת תשלום' : 'إتمام الدفع';
require_once __DIR__ . '/includes/header.php';
?>

<style>
.checkout-container {
    max-width: 600px;
    margin: 2rem auto;
}
.checkout-card {
    background: white;
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    overflow: hidden;
}
.checkout-header {
    background: linear-gradient(135deg, var(--teal) 0%, var(--teal-dark) 100%);
    color: white;
    padding: 2rem;
    text-align: center;
}
.checkout-body {
    padding: 2rem;
}
.plan-summary {
    background: #f8f9fa;
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
}
.plan-summary-row {
    display: flex;
    justify-content: space-between;
    padding: 0.5rem 0;
    border-bottom: 1px solid #eee;
}
.plan-summary-row:last-child {
    border-bottom: none;
    font-weight: bold;
    font-size: 1.2rem;
    color: var(--teal);
}
.payment-method {
    border: 2px solid #eee;
    border-radius: 12px;
    padding: 1rem;
    margin-bottom: 1rem;
    cursor: pointer;
    transition: all 0.3s;
}
.payment-method:hover, .payment-method.selected {
    border-color: var(--teal);
    background: rgba(0, 128, 128, 0.05);
}
.payment-method input[type="radio"] {
    margin-left: 10px;
}
.btn-pay {
    background: linear-gradient(135deg, var(--teal) 0%, var(--teal-dark) 100%);
    color: white;
    border: none;
    padding: 1rem 2rem;
    font-size: 1.1rem;
    border-radius: 12px;
    width: 100%;
    cursor: pointer;
    transition: transform 0.2s;
}
.btn-pay:hover {
    transform: scale(1.02);
    color: white;
}
.success-animation {
    text-align: center;
    padding: 3rem;
}
.success-icon {
    width: 100px;
    height: 100px;
    background: linear-gradient(135deg, #28a745, #20c997);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1.5rem;
    animation: scaleIn 0.5s ease;
}
.success-icon i {
    font-size: 3rem;
    color: white;
}
@keyframes scaleIn {
    0% { transform: scale(0); }
    50% { transform: scale(1.2); }
    100% { transform: scale(1); }
}
.test-badge {
    background: #ffc107;
    color: #000;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.8rem;
    margin-right: 8px;
}
</style>

<div class="container checkout-container">
    <div class="checkout-card">
        <?php if ($success): ?>
        <!-- Success State -->
        <div class="success-animation">
            <div class="success-icon">
                <i class="bi bi-check-lg"></i>
            </div>
            <h2 class="text-success mb-3">
                <?= $lang === 'he' ? 'התשלום הושלם בהצלחה!' : 'تم الدفع بنجاح!' ?>
            </h2>
            <p class="text-muted mb-4">
                <?= $lang === 'he' 
                    ? 'החבילה הופעלה בחשבונך. תוכל להתחיל לפרסם מודעות.'
                    : 'تم تفعيل الباقة في حسابك. يمكنك البدء بنشر إعلاناتك.' ?>
            </p>
            <div class="d-flex gap-3 justify-content-center">
                <a href="add-property.php" class="btn btn-outline-primary">
                    <i class="bi bi-building me-2"></i><?= $lang === 'he' ? 'הוסף נכס' : 'أضف عقار' ?>
                </a>
                <a href="add-car.php" class="btn btn-outline-primary">
                    <i class="bi bi-car-front me-2"></i><?= $lang === 'he' ? 'הוסף רכב' : 'أضف سيارة' ?>
                </a>
            </div>
            <hr class="my-4">
            <a href="profile.php" class="btn btn-link">
                <i class="bi bi-person me-2"></i><?= $lang === 'he' ? 'לחשבון שלי' : 'الذهاب لحسابي' ?>
            </a>
        </div>
        <?php elseif ($pendingTransfer): ?>
        <!-- Pending Bank Transfer -->
        <div class="success-animation">
            <div class="success-icon" style="background: linear-gradient(135deg, #ffc107, #ff9800);">
                <i class="bi bi-hourglass-split"></i>
            </div>
            <h2 class="text-warning mb-3">
                <?= $lang === 'he' ? 'ממתין לאישור' : 'في انتظار التحقق' ?>
            </h2>
            <p class="text-muted mb-4">
                <?= $lang === 'he' 
                    ? 'קיבלנו את פרטי ההעברה. נאשר את התשלום תוך 24 שעות.'
                    : 'تم استلام بيانات الحوالة. سيتم التحقق وتفعيل الباقة خلال 24 ساعة.' ?>
            </p>
            <div class="alert alert-info text-start">
                <strong><i class="bi bi-info-circle me-2"></i><?= $lang === 'he' ? 'מה עכשיו?' : 'ماذا بعد؟' ?></strong>
                <ul class="mb-0 mt-2">
                    <li><?= $lang === 'he' ? 'צוות שלנו יבדוק את ההעברה' : 'فريقنا سيتحقق من الحوالة' ?></li>
                    <li><?= $lang === 'he' ? 'תקבל הודעה כשהחבילה תופעל' : 'ستتلقى إشعاراً عند تفعيل الباقة' ?></li>
                </ul>
            </div>
            <a href="profile.php" class="btn btn-primary mt-3">
                <i class="bi bi-person me-2"></i><?= $lang === 'he' ? 'לחשבון שלי' : 'الذهاب لحسابي' ?>
            </a>
        </div>
        <?php else: ?>
        <!-- Checkout Form -->
        <div class="checkout-header">
            <i class="bi bi-credit-card fs-1 mb-2"></i>
            <h3 class="mb-0"><?= $lang === 'he' ? 'השלמת תשלום' : 'إتمام الدفع' ?></h3>
        </div>
        
        <div class="checkout-body">
            <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="bi bi-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?>
            </div>
            <?php endif; ?>
            
            <!-- Plan Summary -->
            <div class="plan-summary">
                <h5 class="mb-3">
                    <i class="bi bi-box-seam me-2 text-primary"></i>
                    <?= $lang === 'he' ? 'פרטי החבילה' : 'تفاصيل الباقة' ?>
                </h5>
                <div class="plan-summary-row">
                    <span><?= $lang === 'he' ? 'שם החבילה' : 'اسم الباقة' ?></span>
                    <span><?= htmlspecialchars($plan['name_' . $lang] ?? $plan['name_ar']) ?></span>
                </div>
                <div class="plan-summary-row">
                    <span><?= $lang === 'he' ? 'מספר מודעות' : 'عدد الإعلانات' ?></span>
                    <span>
                        <?php if ($plan['is_unlimited']): ?>
                            <?= $lang === 'he' ? 'ללא הגבלה' : 'غير محدود' ?>
                        <?php else: ?>
                            <?= $plan['listings_count'] ?>
                        <?php endif; ?>
                    </span>
                </div>
                <div class="plan-summary-row">
                    <span><?= $lang === 'he' ? 'תקופה' : 'المدة' ?></span>
                    <span><?= $plan['duration_days'] ?> <?= $lang === 'he' ? 'ימים' : 'يوم' ?></span>
                </div>
                <div class="plan-summary-row">
                    <span><?= $lang === 'he' ? 'סה"כ לתשלום' : 'المبلغ الإجمالي' ?></span>
                    <span><?= number_format($plan['price']) ?> ₪</span>
                </div>
            </div>
            
            <!-- Payment Method -->
            <h5 class="mb-3">
                <i class="bi bi-wallet2 me-2 text-primary"></i>
                <?= $lang === 'he' ? 'אמצעי תשלום' : 'طريقة الدفع' ?>
            </h5>
            
            <form method="POST" id="paymentForm">
                <!-- Bank Transfer Option -->
                <label class="payment-method d-flex align-items-center" onclick="selectPayment('bank_transfer')">
                    <input type="radio" name="payment_method" value="bank_transfer" id="pm_bank">
                    <div class="flex-grow-1 ms-3">
                        <strong><i class="bi bi-bank me-2"></i><?= $lang === 'he' ? 'העברה בנקאית' : 'حوالة بنكية' ?></strong>
                        <small class="text-muted d-block">
                            <?= $lang === 'he' ? 'העבר לחשבון הבנק שלנו' : 'حوّل إلى حسابنا البنكي' ?>
                        </small>
                    </div>
                    <i class="bi bi-building text-primary fs-4"></i>
                </label>
                
                <!-- Bank Transfer Details (hidden by default) -->
                <div id="bankTransferDetails" class="mt-3" style="display: none;">
                    <div class="alert alert-secondary">
                        <h6 class="mb-3"><i class="bi bi-bank me-2"></i><?= $lang === 'he' ? 'פרטי חשבון הבנק' : 'تفاصيل الحساب البنكي' ?></h6>
                        <table class="table table-sm table-borderless mb-0">
                            <tr>
                                <td class="text-muted"><?= $lang === 'he' ? 'שם הבנק' : 'اسم البنك' ?>:</td>
                                <td class="fw-bold"><?= $bankDetails['bank_name'] ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted"><?= $lang === 'he' ? 'שם החשבון' : 'اسم الحساب' ?>:</td>
                                <td class="fw-bold"><?= $bankDetails['account_name'] ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted"><?= $lang === 'he' ? 'מספר חשבון' : 'رقم الحساب' ?>:</td>
                                <td class="fw-bold"><?= $bankDetails['account_number'] ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">IBAN:</td>
                                <td class="fw-bold" style="font-size: 0.85rem;"><?= $bankDetails['iban'] ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted"><?= $lang === 'he' ? 'סניף' : 'الفرع' ?>:</td>
                                <td class="fw-bold"><?= $bankDetails['branch'] ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted"><?= $lang === 'he' ? 'סכום' : 'المبلغ' ?>:</td>
                                <td class="fw-bold text-success"><?= number_format($plan['price']) ?> ₪</td>
                            </tr>
                        </table>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label"><?= $lang === 'he' ? 'שם השולח' : 'اسم المُحوِّل' ?> *</label>
                        <input type="text" name="sender_name" class="form-control" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?= $lang === 'he' ? 'תאריך העברה' : 'تاريخ التحويل' ?></label>
                            <input type="date" name="transfer_date" class="form-control" value="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?= $lang === 'he' ? 'מספר אסמכתא' : 'رقم المرجع' ?></label>
                            <input type="text" name="transfer_reference" class="form-control" placeholder="<?= $lang === 'he' ? 'אופציונלי' : 'اختياري' ?>">
                        </div>
                    </div>
                </div>
                
                <!-- Apple Pay Option -->
                <label class="payment-method d-flex align-items-center mt-2" onclick="selectPayment('apple_pay')">
                    <input type="radio" name="payment_method" value="apple_pay" id="pm_apple">
                    <div class="flex-grow-1 ms-3">
                        <strong><i class="bi bi-apple me-2"></i>Apple Pay</strong>
                        <small class="text-muted d-block"><?= $lang === 'he' ? 'תשלום מהיר ומאובטח' : 'دفع سريع وآمن' ?></small>
                    </div>
                    <i class="bi bi-apple text-dark fs-4"></i>
                </label>
                
                <!-- Google Pay Option -->
                <label class="payment-method d-flex align-items-center mt-2" onclick="selectPayment('google_pay')">
                    <input type="radio" name="payment_method" value="google_pay" id="pm_google">
                    <div class="flex-grow-1 ms-3">
                        <strong><i class="bi bi-google me-2"></i>Google Pay</strong>
                        <small class="text-muted d-block"><?= $lang === 'he' ? 'תשלום מהיר ומאובטח' : 'دفع سريع وآمن' ?></small>
                    </div>
                    <i class="bi bi-google text-primary fs-4"></i>
                </label>
                
                <!-- Test Payment (for development) -->
                <label class="payment-method selected d-flex align-items-center mt-2" onclick="selectPayment('test')">
                    <input type="radio" name="payment_method" value="test" id="pm_test" checked>
                    <div class="flex-grow-1 ms-3">
                        <div class="d-flex align-items-center">
                            <span class="test-badge">TEST</span>
                            <strong><?= $lang === 'he' ? 'תשלום לבדיקה' : 'دفع تجريبي' ?></strong>
                        </div>
                        <small class="text-muted">
                            <?= $lang === 'he' ? 'לבדיקה בלבד' : 'للاختبار فقط' ?>
                        </small>
                    </div>
                    <i class="bi bi-patch-check-fill text-warning fs-4"></i>
                </label>
                
                <button type="submit" name="pay" class="btn btn-pay mt-4">
                    <i class="bi bi-lock me-2"></i>
                    <span id="payBtnText"><?= $lang === 'he' ? 'שלם עכשיו' : 'ادفع الآن' ?></span> - <?= number_format($plan['price']) ?> ₪
                </button>
            </form>
            
            <script>
            function selectPayment(method) {
                document.querySelectorAll('.payment-method').forEach(el => el.classList.remove('selected'));
                document.querySelector('input[value="'+method+'"]').closest('.payment-method').classList.add('selected');
                document.querySelector('input[value="'+method+'"]').checked = true;
                
                const bankDetails = document.getElementById('bankTransferDetails');
                const payBtn = document.getElementById('payBtnText');
                
                if (method === 'bank_transfer') {
                    bankDetails.style.display = 'block';
                    payBtn.textContent = '<?= $lang === 'he' ? 'אשר העברה' : 'تأكيد الحوالة' ?>';
                } else {
                    bankDetails.style.display = 'none';
                    payBtn.textContent = '<?= $lang === 'he' ? 'שלם עכשיו' : 'ادفع الآن' ?>';
                }
            }
            </script>
            
            <div class="text-center mt-3">
                <a href="packages.php?category=<?= $plan['category'] ?>" class="text-muted">
                    <i class="bi bi-arrow-right me-1"></i>
                    <?= $lang === 'he' ? 'חזרה לחבילות' : 'العودة للباقات' ?>
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
