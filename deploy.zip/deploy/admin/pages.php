<?php
session_start();
require_once __DIR__ . '/../backend/config/database.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$db = Database::getInstance();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $slug = $_POST['slug'];
    $data = [
        'title_ar' => $_POST['title_ar'],
        'title_en' => $_POST['title_en'],
        'title_he' => $_POST['title_he'],
        'content_ar' => $_POST['content_ar'],
        'content_en' => $_POST['content_en'],
        'content_he' => $_POST['content_he'],
    ];
    
    $db->update('cms_pages', $data, 'slug = ?', [$slug]);
    $message = 'تم حفظ الصفحة بنجاح';
}

$pages = $db->fetchAll("SELECT * FROM cms_pages ORDER BY slug");
$editPage = null;
if (isset($_GET['edit'])) {
    $editPage = $db->fetch("SELECT * FROM cms_pages WHERE slug = ?", [$_GET['edit']]);
}

include 'includes/header.php';
?>

<div class="container-fluid py-4">
    <h1 class="h3 mb-4">الصفحات القانونية (CMS)</h1>

    <?php if ($message): ?>
    <div class="alert alert-success"><?= $message ?></div>
    <?php endif; ?>

    <div class="row g-4">
        <div class="col-md-3">
            <div class="card">
                <div class="card-header"><h5 class="mb-0">الصفحات</h5></div>
                <div class="list-group list-group-flush">
                    <?php foreach ($pages as $page): ?>
                    <a href="?edit=<?= $page['slug'] ?>" class="list-group-item list-group-item-action <?= ($editPage['slug'] ?? '') === $page['slug'] ? 'active' : '' ?>">
                        <?= htmlspecialchars($page['title_ar']) ?>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <div class="col-md-9">
            <?php if ($editPage): ?>
            <div class="card">
                <div class="card-header"><h5 class="mb-0">تعديل: <?= htmlspecialchars($editPage['title_ar']) ?></h5></div>
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="slug" value="<?= $editPage['slug'] ?>">
                        <ul class="nav nav-tabs mb-3" role="tablist">
                            <li class="nav-item"><a class="nav-link active" data-bs-toggle="tab" href="#ar">العربية</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#en">English</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#he">עברית</a></li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="ar">
                                <div class="mb-3">
                                    <label class="form-label">العنوان</label>
                                    <input type="text" name="title_ar" class="form-control" value="<?= htmlspecialchars($editPage['title_ar']) ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">المحتوى</label>
                                    <textarea name="content_ar" class="form-control" rows="15"><?= htmlspecialchars($editPage['content_ar']) ?></textarea>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="en">
                                <div class="mb-3">
                                    <label class="form-label">Title</label>
                                    <input type="text" name="title_en" class="form-control" value="<?= htmlspecialchars($editPage['title_en']) ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Content</label>
                                    <textarea name="content_en" class="form-control" rows="15"><?= htmlspecialchars($editPage['content_en']) ?></textarea>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="he" dir="rtl">
                                <div class="mb-3">
                                    <label class="form-label">כותרת</label>
                                    <input type="text" name="title_he" class="form-control" value="<?= htmlspecialchars($editPage['title_he']) ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">תוכן</label>
                                    <textarea name="content_he" class="form-control" rows="15"><?= htmlspecialchars($editPage['content_he']) ?></textarea>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> حفظ</button>
                    </form>
                </div>
            </div>
            <?php else: ?>
            <div class="card"><div class="card-body text-center text-muted py-5">اختر صفحة للتعديل</div></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
