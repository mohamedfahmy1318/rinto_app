<?php
session_start();
require_once __DIR__ . '/../backend/config/database.php';

if (!isset($_SESSION['admin_id']) || $_SESSION['admin_role'] !== 'super_admin') {
    header('Location: index.php');
    exit;
}

$db = Database::getInstance();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    
    if ($action === 'add') {
        $db->insert('admin_users', [
            'name' => $_POST['name'],
            'email' => $_POST['email'],
            'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
            'role' => $_POST['role']
        ]);
        $message = 'تم إضافة المشرف';
    } elseif ($action === 'toggle') {
        $id = (int)$_POST['id'];
        $current = $db->fetch("SELECT is_active FROM admin_users WHERE id = ?", [$id]);
        $db->update('admin_users', ['is_active' => !$current['is_active']], 'id = ?', [$id]);
        $message = 'تم تحديث الحالة';
    }
}

$admins = $db->fetchAll("SELECT * FROM admin_users ORDER BY id");

include 'includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">إدارة المشرفين</h1>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">
            <i class="bi bi-plus-lg me-1"></i> إضافة مشرف
        </button>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-success"><?= $message ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body p-0">
            <table class="table table-hover mb-0">
                <thead>
                    <tr><th>#</th><th>الاسم</th><th>الإيميل</th><th>الدور</th><th>آخر دخول</th><th>الحالة</th><th>إجراءات</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($admins as $admin): ?>
                    <tr>
                        <td><?= $admin['id'] ?></td>
                        <td><?= htmlspecialchars($admin['name']) ?></td>
                        <td><?= htmlspecialchars($admin['email']) ?></td>
                        <td><span class="badge bg-<?= $admin['role'] === 'super_admin' ? 'danger' : 'primary' ?>"><?= $admin['role'] ?></span></td>
                        <td><?= $admin['last_login'] ? date('Y/m/d H:i', strtotime($admin['last_login'])) : '-' ?></td>
                        <td><?= $admin['is_active'] ? '<span class="badge bg-success">نشط</span>' : '<span class="badge bg-secondary">معطل</span>' ?></td>
                        <td>
                            <?php if ($admin['id'] != $_SESSION['admin_id']): ?>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="action" value="toggle">
                                <input type="hidden" name="id" value="<?= $admin['id'] ?>">
                                <button class="btn btn-sm btn-outline-warning"><?= $admin['is_active'] ? 'تعطيل' : 'تفعيل' ?></button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="addModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="action" value="add">
                <div class="modal-header"><h5>إضافة مشرف</h5></div>
                <div class="modal-body">
                    <div class="mb-3"><label class="form-label">الاسم</label><input type="text" name="name" class="form-control" required></div>
                    <div class="mb-3"><label class="form-label">الإيميل</label><input type="email" name="email" class="form-control" required></div>
                    <div class="mb-3"><label class="form-label">كلمة المرور</label><input type="password" name="password" class="form-control" required></div>
                    <div class="mb-3"><label class="form-label">الدور</label>
                        <select name="role" class="form-select">
                            <option value="admin">Admin</option>
                            <option value="moderator">Moderator</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <button type="submit" class="btn btn-primary">إضافة</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
