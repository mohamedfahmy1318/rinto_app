<?php
session_start();
require_once __DIR__ . '/../backend/config/database.php';
require_once __DIR__ . '/../backend/config/constants.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$db = Database::getInstance();
$message = '';
$messageType = 'success';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'save_settings') {
        $settings = $_POST['settings'] ?? [];
        
        foreach ($settings as $key => $value) {
            // Check if setting exists
            $existing = $db->fetch("SELECT id FROM app_settings WHERE setting_key = ?", [$key]);
            
            if ($existing) {
                $db->query(
                    "UPDATE app_settings SET value_ar = ?, updated_at = NOW(), updated_by = ? WHERE setting_key = ?",
                    [$value, $_SESSION['admin_id'], $key]
                );
            }
        }
        
        $message = 'تم حفظ الإعدادات بنجاح';
    } elseif ($action === 'test_connection') {
        $gateway = $_POST['gateway'] ?? '';
        // Test connection logic would go here
        $message = 'تم اختبار الاتصال - هذه الميزة ستكون متاحة قريباً';
        $messageType = 'info';
    }
}

// Get all payment-related settings grouped
$settingGroups = [
    'payment' => ['title' => 'إعدادات الدفع العامة', 'icon' => 'bi-credit-card'],
    'apple_pay' => ['title' => 'Apple Pay', 'icon' => 'bi-apple'],
    'stripe' => ['title' => 'Stripe', 'icon' => 'bi-stripe'],
    'paypal' => ['title' => 'PayPal', 'icon' => 'bi-paypal'],
    'notifications' => ['title' => 'الإشعارات', 'icon' => 'bi-bell']
];

$settings = [];
foreach (array_keys($settingGroups) as $group) {
    $settings[$group] = $db->fetchAll(
        "SELECT * FROM app_settings WHERE setting_group = ? ORDER BY id",
        [$group]
    );
}

$pageTitle = 'إعدادات الدفع';
require_once 'includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col">
            <h2><i class="bi bi-credit-card-2-front"></i> إعدادات الدفع</h2>
            <p class="text-muted">إدارة بوابات الدفع وإعدادات المعاملات المالية</p>
        </div>
    </div>
    
    <?php if ($message): ?>
    <div class="alert alert-<?= $messageType ?> alert-dismissible fade show">
        <?= htmlspecialchars($message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>
    
    <form method="POST" id="settingsForm">
        <input type="hidden" name="action" value="save_settings">
        
        <div class="row">
            <div class="col-lg-3">
                <!-- Settings Navigation -->
                <div class="card mb-4">
                    <div class="card-body p-0">
                        <div class="nav flex-column nav-pills" id="settings-tabs" role="tablist">
                            <?php $first = true; foreach ($settingGroups as $groupKey => $groupInfo): ?>
                            <button class="nav-link <?= $first ? 'active' : '' ?> text-start" 
                                    id="<?= $groupKey ?>-tab" 
                                    data-bs-toggle="pill" 
                                    data-bs-target="#<?= $groupKey ?>-content" 
                                    type="button" role="tab">
                                <i class="<?= $groupInfo['icon'] ?> me-2"></i>
                                <?= $groupInfo['title'] ?>
                                <?php if (!empty($settings[$groupKey])): ?>
                                    <?php 
                                    $enabledKey = $groupKey . '_enabled';
                                    $isEnabled = false;
                                    foreach ($settings[$groupKey] as $s) {
                                        if ($s['setting_key'] === $enabledKey && $s['value_ar'] === '1') {
                                            $isEnabled = true;
                                            break;
                                        }
                                    }
                                    if ($isEnabled): ?>
                                        <span class="badge bg-success ms-2">مفعّل</span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </button>
                            <?php $first = false; endforeach; ?>
                        </div>
                    </div>
                </div>
                
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="bi bi-check-lg"></i> حفظ جميع الإعدادات
                    </button>
                </div>
            </div>
            
            <div class="col-lg-9">
                <div class="tab-content" id="settings-content">
                    <?php $first = true; foreach ($settingGroups as $groupKey => $groupInfo): ?>
                    <div class="tab-pane fade <?= $first ? 'show active' : '' ?>" 
                         id="<?= $groupKey ?>-content" 
                         role="tabpanel">
                        
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">
                                    <i class="<?= $groupInfo['icon'] ?> me-2"></i>
                                    <?= $groupInfo['title'] ?>
                                </h5>
                                <?php if ($groupKey !== 'payment' && $groupKey !== 'notifications'): ?>
                                <button type="button" class="btn btn-outline-secondary btn-sm" 
                                        onclick="testConnection('<?= $groupKey ?>')">
                                    <i class="bi bi-lightning"></i> اختبار الاتصال
                                </button>
                                <?php endif; ?>
                            </div>
                            <div class="card-body">
                                <?php if (empty($settings[$groupKey])): ?>
                                    <div class="alert alert-warning">
                                        <i class="bi bi-exclamation-triangle"></i>
                                        لم يتم العثور على إعدادات. يرجى تشغيل migration أولاً.
                                    </div>
                                <?php else: ?>
                                    <?php foreach ($settings[$groupKey] as $setting): ?>
                                    <div class="mb-3 row">
                                        <label class="col-sm-4 col-form-label">
                                            <?= getSettingLabel($setting['setting_key']) ?>
                                            <?php if ($setting['is_sensitive']): ?>
                                                <i class="bi bi-shield-lock text-warning" title="حقل حساس"></i>
                                            <?php endif; ?>
                                        </label>
                                        <div class="col-sm-8">
                                            <?php if ($setting['setting_type'] === 'boolean'): ?>
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" type="checkbox" 
                                                           name="settings[<?= $setting['setting_key'] ?>]" 
                                                           value="1"
                                                           <?= $setting['value_ar'] === '1' ? 'checked' : '' ?>>
                                                    <label class="form-check-label">
                                                        <?= $setting['value_ar'] === '1' ? 'مفعّل' : 'معطّل' ?>
                                                    </label>
                                                </div>
                                            <?php elseif ($setting['setting_type'] === 'password'): ?>
                                                <div class="input-group">
                                                    <input type="password" class="form-control" 
                                                           name="settings[<?= $setting['setting_key'] ?>]" 
                                                           value="<?= htmlspecialchars($setting['value_ar'] ?? '') ?>"
                                                           placeholder="<?= $setting['is_sensitive'] && !empty($setting['value_ar']) ? '••••••••' : '' ?>">
                                                    <button class="btn btn-outline-secondary toggle-password" type="button">
                                                        <i class="bi bi-eye"></i>
                                                    </button>
                                                </div>
                                            <?php elseif ($setting['setting_type'] === 'json'): ?>
                                                <textarea class="form-control font-monospace" rows="3"
                                                          name="settings[<?= $setting['setting_key'] ?>]"><?= htmlspecialchars($setting['value_ar'] ?? '') ?></textarea>
                                                <small class="text-muted">JSON format</small>
                                            <?php else: ?>
                                                <input type="text" class="form-control" 
                                                       name="settings[<?= $setting['setting_key'] ?>]" 
                                                       value="<?= htmlspecialchars($setting['value_ar'] ?? '') ?>">
                                            <?php endif; ?>
                                            
                                            <?php if ($setting['description']): ?>
                                                <small class="text-muted d-block mt-1">
                                                    <?= htmlspecialchars($setting['description']) ?>
                                                </small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <?php if ($groupKey === 'apple_pay'): ?>
                        <div class="card mt-3">
                            <div class="card-header">
                                <h6 class="mb-0"><i class="bi bi-info-circle"></i> معلومات هامة عن Apple Pay</h6>
                            </div>
                            <div class="card-body">
                                <ol class="mb-0">
                                    <li>يجب أن يكون لديك حساب مطور Apple</li>
                                    <li>قم بإنشاء Merchant ID في Apple Developer Portal</li>
                                    <li>قم بإنشاء شهادة Payment Processing Certificate</li>
                                    <li>قم بتحميل الشهادة وتحويلها إلى صيغة PEM</li>
                                    <li>تأكد من التحقق من الدومين في Apple Pay</li>
                                </ol>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                    </div>
                    <?php $first = false; endforeach; ?>
                </div>
            </div>
        </div>
    </form>
</div>

<style>
.nav-pills .nav-link {
    border-radius: 0;
    padding: 12px 20px;
    color: #333;
    border-bottom: 1px solid #eee;
}
.nav-pills .nav-link:last-child {
    border-bottom: none;
}
.nav-pills .nav-link.active {
    background-color: var(--bs-primary);
    color: white;
}
.font-monospace {
    font-family: 'Courier New', monospace;
    font-size: 12px;
}
</style>

<script>
document.querySelectorAll('.toggle-password').forEach(btn => {
    btn.addEventListener('click', function() {
        const input = this.parentElement.querySelector('input');
        const icon = this.querySelector('i');
        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.replace('bi-eye', 'bi-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.replace('bi-eye-slash', 'bi-eye');
        }
    });
});

function testConnection(gateway) {
    if (!confirm('هل تريد اختبار الاتصال بـ ' + gateway + '؟')) return;
    
    const form = document.createElement('form');
    form.method = 'POST';
    form.innerHTML = `
        <input type="hidden" name="action" value="test_connection">
        <input type="hidden" name="gateway" value="${gateway}">
    `;
    document.body.appendChild(form);
    form.submit();
}

// Handle boolean checkboxes - ensure unchecked sends 0
document.getElementById('settingsForm').addEventListener('submit', function(e) {
    this.querySelectorAll('input[type="checkbox"]').forEach(cb => {
        if (!cb.checked) {
            const hidden = document.createElement('input');
            hidden.type = 'hidden';
            hidden.name = cb.name;
            hidden.value = '0';
            this.appendChild(hidden);
        }
    });
});
</script>

<?php
require_once 'includes/footer.php';

function getSettingLabel($key) {
    $labels = [
        'payment_mode' => 'بيئة الدفع',
        'payment_currency' => 'العملة الافتراضية',
        'apple_pay_enabled' => 'تفعيل Apple Pay',
        'apple_pay_merchant_id' => 'Merchant ID',
        'apple_pay_merchant_name' => 'اسم التاجر',
        'apple_pay_certificate_path' => 'مسار الشهادة',
        'apple_pay_certificate_key' => 'المفتاح الخاص',
        'apple_pay_merchant_domain' => 'الدومين المعتمد',
        'apple_pay_supported_networks' => 'الشبكات المدعومة',
        'stripe_enabled' => 'تفعيل Stripe',
        'stripe_publishable_key' => 'Publishable Key',
        'stripe_secret_key' => 'Secret Key',
        'stripe_webhook_secret' => 'Webhook Secret',
        'paypal_enabled' => 'تفعيل PayPal',
        'paypal_client_id' => 'Client ID',
        'paypal_client_secret' => 'Client Secret',
        'paypal_mode' => 'بيئة PayPal',
        'admin_notification_email' => 'بريد الإشعارات',
        'payment_success_webhook' => 'Webhook نجاح الدفع',
        'payment_failed_webhook' => 'Webhook فشل الدفع'
    ];
    return $labels[$key] ?? $key;
}
?>
