<?php
session_start();
require_once __DIR__ . '/../backend/config/database.php';
require_once __DIR__ . '/../backend/config/constants.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$db = Database::getInstance();

// Handle actions
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $userId = (int)($_POST['user_id'] ?? 0);
    
    if ($userId) {
        switch ($action) {
            case 'block':
                $db->update('users', ['is_blocked' => 1], 'id = ?', [$userId]);
                $message = 'تم حظر المستخدم';
                break;
            case 'unblock':
                $db->update('users', ['is_blocked' => 0], 'id = ?', [$userId]);
                $message = 'تم إلغاء حظر المستخدم';
                break;
            case 'trust':
                $trustedUntil = date('Y-m-d', strtotime('+1 month'));
                $db->update('users', ['is_trusted' => 1, 'trusted_until' => $trustedUntil], 'id = ?', [$userId]);
                $message = 'تم توثيق المستخدم';
                break;
            case 'untrust':
                $db->update('users', ['is_trusted' => 0, 'trusted_until' => null], 'id = ?', [$userId]);
                $message = 'تم إلغاء توثيق المستخدم';
                break;
            case 'approve':
                $db->update('users', ['is_approved' => 1], 'id = ?', [$userId]);
                $message = 'تم الموافقة على المستخدم';
                break;
            case 'reject':
                $db->update('users', ['is_approved' => 0], 'id = ?', [$userId]);
                $message = 'تم رفض المستخدم';
                break;
            case 'verify_phone':
                $db->update('users', ['is_verified_phone' => 1], 'id = ?', [$userId]);
                $message = 'تم تفعيل رقم الهاتف';
                break;
            case 'verify_email':
                $db->update('users', ['is_verified_email' => 1], 'id = ?', [$userId]);
                $message = 'تم تفعيل البريد الإلكتروني';
                break;
        }
    }
}

$search = $_GET['search'] ?? '';
$userType = $_GET['user_type'] ?? '';
$approvalStatus = $_GET['approval'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

$where = "1=1";
$params = [];

if ($search) {
    $where .= " AND (name LIKE ? OR email LIKE ? OR phone LIKE ? OR company_name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($userType) {
    $where .= " AND user_type = ?";
    $params[] = $userType;
}

if ($approvalStatus !== '') {
    $where .= " AND is_approved = ?";
    $params[] = (int)$approvalStatus;
}

$total = $db->fetch("SELECT COUNT(*) as total FROM users WHERE $where", $params)['total'];
$users = $db->fetchAll("SELECT * FROM users WHERE $where ORDER BY created_at DESC LIMIT $perPage OFFSET $offset", $params);

// Get listings count for each user
foreach ($users as &$user) {
    $counts = $db->fetch("
        SELECT 
            (SELECT COUNT(*) FROM properties WHERE user_id = ?) as properties,
            (SELECT COUNT(*) FROM cars WHERE user_id = ?) as cars
    ", [$user['id'], $user['id']]);
    $user['properties_count'] = $counts['properties'];
    $user['cars_count'] = $counts['cars'];
}

include 'includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="h3 mb-0">إدارة المستخدمين</h1>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <!-- Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <input type="text" name="search" class="form-control" placeholder="بحث بالاسم أو الإيميل أو الهاتف..." 
                           value="<?= htmlspecialchars($search) ?>">
                </div>
                <div class="col-md-2">
                    <select name="user_type" class="form-select">
                        <option value="">كل الأنواع</option>
                        <?php foreach (USER_TYPES as $key => $val): ?>
                        <option value="<?= $key ?>" <?= $userType === $key ? 'selected' : '' ?>><?= $val['ar'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="approval" class="form-select">
                        <option value="">كل الحالات</option>
                        <option value="0" <?= $approvalStatus === '0' ? 'selected' : '' ?>>بانتظار الموافقة</option>
                        <option value="1" <?= $approvalStatus === '1' ? 'selected' : '' ?>>موافق عليه</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-search me-1"></i> بحث
                    </button>
                </div>
                <div class="col-md-3">
                    <a href="?approval=0" class="btn btn-warning w-100">
                        <i class="bi bi-clock me-1"></i> بانتظار الموافقة
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Users Table -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">المستخدمين (<?= $total ?>)</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>الاسم</th>
                            <th>الإيميل</th>
                            <th>الهاتف</th>
                            <th>النوع</th>
                            <th>التحقق</th>
                            <th>الموافقة</th>
                            <th>الحالة</th>
                            <th>الإعلانات</th>
                            <th>التاريخ</th>
                            <th>إجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                        <tr class="<?= !$user['is_approved'] ? 'table-warning' : '' ?>">
                            <td><?= $user['id'] ?></td>
                            <td>
                                <strong><?= htmlspecialchars($user['name']) ?></strong>
                                <?php if ($user['company_name']): ?>
                                <br><small class="text-muted"><?= htmlspecialchars($user['company_name']) ?></small>
                                <?php endif; ?>
                                <?php if ($user['is_trusted']): ?>
                                <span class="badge bg-success">موثق</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?= htmlspecialchars($user['email']) ?>
                                <?php if ($user['is_verified_email']): ?>
                                <i class="bi bi-check-circle-fill text-success" title="تم التحقق"></i>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?= htmlspecialchars($user['phone']) ?>
                                <?php if ($user['is_verified_phone']): ?>
                                <i class="bi bi-check-circle-fill text-success" title="تم التحقق"></i>
                                <?php endif; ?>
                            </td>
                            <td><?= USER_TYPES[$user['user_type']]['ar'] ?? $user['user_type'] ?></td>
                            <td>
                                <?php if ($user['is_verified_phone']): ?>
                                <span class="badge bg-success">هاتف ✓</span>
                                <?php else: ?>
                                <span class="badge bg-secondary">هاتف ✗</span>
                                <?php endif; ?>
                                <?php if ($user['is_verified_email']): ?>
                                <span class="badge bg-success">إيميل ✓</span>
                                <?php else: ?>
                                <span class="badge bg-secondary">إيميل ✗</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($user['is_approved']): ?>
                                <span class="badge bg-success">موافق عليه</span>
                                <?php else: ?>
                                <span class="badge bg-warning text-dark">بانتظار الموافقة</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($user['is_blocked']): ?>
                                <span class="badge bg-danger">محظور</span>
                                <?php elseif ($user['is_active']): ?>
                                <span class="badge bg-success">نشط</span>
                                <?php else: ?>
                                <span class="badge bg-secondary">غير نشط</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-info"><?= $user['properties_count'] ?> عقار</span>
                                <span class="badge bg-secondary"><?= $user['cars_count'] ?> سيارة</span>
                            </td>
                            <td><?= date('Y/m/d', strtotime($user['created_at'])) ?></td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                        إجراءات
                                    </button>
                                    <ul class="dropdown-menu">
                                        <!-- Approval Actions -->
                                        <?php if (!$user['is_approved']): ?>
                                        <li>
                                            <form method="POST">
                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                <button type="submit" name="action" value="approve" class="dropdown-item text-success">
                                                    <i class="bi bi-check-lg me-1"></i> موافقة على الحساب
                                                </button>
                                            </form>
                                        </li>
                                        <?php else: ?>
                                        <li>
                                            <form method="POST">
                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                <button type="submit" name="action" value="reject" class="dropdown-item text-danger">
                                                    <i class="bi bi-x-lg me-1"></i> إلغاء الموافقة
                                                </button>
                                            </form>
                                        </li>
                                        <?php endif; ?>
                                        
                                        <li><hr class="dropdown-divider"></li>
                                        
                                        <!-- Block/Unblock -->
                                        <?php if ($user['is_blocked']): ?>
                                        <li>
                                            <form method="POST">
                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                <button type="submit" name="action" value="unblock" class="dropdown-item text-success">
                                                    <i class="bi bi-unlock me-1"></i> إلغاء الحظر
                                                </button>
                                            </form>
                                        </li>
                                        <?php else: ?>
                                        <li>
                                            <form method="POST">
                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                <button type="submit" name="action" value="block" class="dropdown-item text-danger">
                                                    <i class="bi bi-lock me-1"></i> حظر
                                                </button>
                                            </form>
                                        </li>
                                        <?php endif; ?>
                                        
                                        <li><hr class="dropdown-divider"></li>
                                        
                                        <!-- Trust/Untrust -->
                                        <?php if ($user['is_trusted']): ?>
                                        <li>
                                            <form method="POST">
                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                <button type="submit" name="action" value="untrust" class="dropdown-item">
                                                    <i class="bi bi-star me-1"></i> إلغاء التوثيق
                                                </button>
                                            </form>
                                        </li>
                                        <?php else: ?>
                                        <li>
                                            <form method="POST">
                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                <button type="submit" name="action" value="trust" class="dropdown-item text-warning">
                                                    <i class="bi bi-star-fill me-1"></i> توثيق
                                                </button>
                                            </form>
                                        </li>
                                        <?php endif; ?>
                                        
                                        <li><hr class="dropdown-divider"></li>
                                        
                                        <!-- Verify Phone/Email -->
                                        <?php if (!$user['is_verified_phone']): ?>
                                        <li>
                                            <form method="POST">
                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                <button type="submit" name="action" value="verify_phone" class="dropdown-item">
                                                    <i class="bi bi-phone me-1"></i> تفعيل الهاتف
                                                </button>
                                            </form>
                                        </li>
                                        <?php endif; ?>
                                        <?php if (!$user['is_verified_email']): ?>
                                        <li>
                                            <form method="POST">
                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                <button type="submit" name="action" value="verify_email" class="dropdown-item">
                                                    <i class="bi bi-envelope me-1"></i> تفعيل الإيميل
                                                </button>
                                            </form>
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
