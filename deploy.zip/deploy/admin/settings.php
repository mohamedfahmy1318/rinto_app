<?php
session_start();
require_once '../config.php';

// Check admin authentication
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$pdo = getDBConnection();
$message = '';
$messageType = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $settingKey = $_POST['setting_key'] ?? '';
    $valueAr = $_POST['value_ar'] ?? '';
    $valueEn = $_POST['value_en'] ?? '';
    $valueHe = $_POST['value_he'] ?? '';
    
    if ($settingKey) {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO app_settings (setting_key, value_ar, value_en, value_he, updated_by)
                VALUES (?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE 
                    value_ar = VALUES(value_ar),
                    value_en = VALUES(value_en),
                    value_he = VALUES(value_he),
                    updated_by = VALUES(updated_by)
            ");
            $stmt->execute([$settingKey, $valueAr, $valueEn, $valueHe, $_SESSION['admin_id'] ?? 1]);
            $message = 'تم حفظ الإعدادات بنجاح';
            $messageType = 'success';
        } catch (Exception $e) {
            $message = 'خطأ: ' . $e->getMessage();
            $messageType = 'error';
        }
    }
}

// Get current settings
$settings = [];
try {
    $stmt = $pdo->query("SELECT * FROM app_settings ORDER BY setting_key");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $settings[$row['setting_key']] = $row;
    }
} catch (Exception $e) {
    // Table might not exist yet
}

$currentSetting = $_GET['edit'] ?? 'terms_of_service';
$currentData = $settings[$currentSetting] ?? ['value_ar' => '', 'value_en' => '', 'value_he' => ''];

include 'includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header pb-0">
                    <h5>إدارة الإعدادات والشروط</h5>
                </div>
                <div class="card-body">
                    <?php if ($message): ?>
                        <div class="alert alert-<?= $messageType === 'success' ? 'success' : 'danger' ?> alert-dismissible fade show">
                            <?= htmlspecialchars($message) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <ul class="nav nav-tabs mb-4">
                        <li class="nav-item">
                            <a class="nav-link <?= $currentSetting === 'terms_of_service' ? 'active' : '' ?>" 
                               href="?edit=terms_of_service">
                                <i class="fas fa-file-contract me-2"></i>شروط الاستخدام
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $currentSetting === 'privacy_policy' ? 'active' : '' ?>" 
                               href="?edit=privacy_policy">
                                <i class="fas fa-shield-alt me-2"></i>سياسة الخصوصية
                            </a>
                        </li>
                    </ul>
                    
                    <form method="POST">
                        <input type="hidden" name="setting_key" value="<?= htmlspecialchars($currentSetting) ?>">
                        
                        <ul class="nav nav-pills mb-3" id="langTabs" role="tablist">
                            <li class="nav-item">
                                <button class="nav-link active" id="ar-tab" data-bs-toggle="pill" 
                                        data-bs-target="#ar-content" type="button">العربية</button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="en-tab" data-bs-toggle="pill" 
                                        data-bs-target="#en-content" type="button">English</button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="he-tab" data-bs-toggle="pill" 
                                        data-bs-target="#he-content" type="button">עברית</button>
                            </li>
                        </ul>
                        
                        <div class="tab-content" id="langTabsContent">
                            <div class="tab-pane fade show active" id="ar-content" role="tabpanel">
                                <div class="mb-3">
                                    <label class="form-label">المحتوى بالعربية</label>
                                    <textarea name="value_ar" class="form-control" rows="15" dir="rtl"
                                    ><?= htmlspecialchars($currentData['value_ar'] ?? '') ?></textarea>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="en-content" role="tabpanel">
                                <div class="mb-3">
                                    <label class="form-label">Content in English</label>
                                    <textarea name="value_en" class="form-control" rows="15" dir="ltr"
                                    ><?= htmlspecialchars($currentData['value_en'] ?? '') ?></textarea>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="he-content" role="tabpanel">
                                <div class="mb-3">
                                    <label class="form-label">תוכן בעברית</label>
                                    <textarea name="value_he" class="form-control" rows="15" dir="rtl"
                                    ><?= htmlspecialchars($currentData['value_he'] ?? '') ?></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center mt-4">
                            <small class="text-muted">
                                <?php if (!empty($currentData['updated_at'])): ?>
                                    آخر تحديث: <?= date('Y-m-d H:i', strtotime($currentData['updated_at'])) ?>
                                <?php endif; ?>
                            </small>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>حفظ التغييرات
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Optional: Add WYSIWYG editor like TinyMCE or CKEditor
// For now, using plain textarea with HTML support
</script>

<?php include 'includes/footer.php'; ?>
