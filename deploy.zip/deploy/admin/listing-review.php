<?php
session_start();
require_once __DIR__ . '/../backend/config/database.php';
require_once __DIR__ . '/../backend/config/constants.php';
require_once __DIR__ . '/../backend/helpers/FCM.php';
require_once __DIR__ . '/../backend/api/controllers/NotificationController.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$db = Database::getInstance();

$type = $_GET['type'] ?? 'property';
$id = (int)($_GET['id'] ?? 0);

if (!$id) {
    header('Location: listings.php');
    exit;
}

$table = $type === 'car' ? 'cars' : 'properties';
$mediaTable = $type === 'car' ? 'car_media' : 'property_media';
$foreignKey = $type === 'car' ? 'car_id' : 'property_id';

// Handle actions
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'approve') {
        $db->update($table, ['status' => 'active'], 'id = ?', [$id]);
        
        $listing = $db->fetch("SELECT user_id, city_id, region_id, title, subscription_id FROM $table WHERE id = ?", [$id]);
        NotificationController::send($listing['user_id'], 'listing_approved', [
            'listing_id' => $id,
            'listing_type' => $type
        ]);
        
        // Notify users in the same region about the new listing (if subscription allows)
        NotificationController::notifyNewListingInRegion(
            $listing['region_id'],
            $type,
            $id,
            $listing['title'],
            $listing['subscription_id'],
            $listing['user_id'] // Exclude the listing owner
        );
        
        // Log action
        $db->insert('audit_logs', [
            'admin_id' => $_SESSION['admin_id'],
            'action' => 'approve_listing',
            'entity_type' => $table,
            'entity_id' => $id,
            'ip_address' => $_SERVER['REMOTE_ADDR']
        ]);
        
        $message = 'تم نشر الإعلان بنجاح';
        $messageType = 'success';
        
    } elseif ($action === 'pause') {
        $db->update($table, ['status' => 'paused'], 'id = ?', [$id]);
        
        // Log action
        $db->insert('audit_logs', [
            'admin_id' => $_SESSION['admin_id'],
            'action' => 'pause_listing',
            'entity_type' => $table,
            'entity_id' => $id,
            'ip_address' => $_SERVER['REMOTE_ADDR']
        ]);
        
        $message = 'تم إيقاف الإعلان';
        $messageType = 'warning';
        
    } elseif ($action === 'reject') {
        $reason = $_POST['reject_reason'] ?? '';
        
        if (empty($reason)) {
            $message = 'يجب إدخال سبب الرفض';
            $messageType = 'danger';
        } else {
            $db->update($table, [
                'status' => 'rejected',
                'reject_reason' => $reason
            ], 'id = ?', [$id]);
            
            $listing = $db->fetch("SELECT user_id FROM $table WHERE id = ?", [$id]);
            NotificationController::send($listing['user_id'], 'listing_rejected', [
                'listing_id' => $id,
                'listing_type' => $type,
                'reason' => $reason
            ]);
            
            // Log action
            $db->insert('audit_logs', [
                'admin_id' => $_SESSION['admin_id'],
                'action' => 'reject_listing',
                'entity_type' => $table,
                'entity_id' => $id,
                'new_data' => json_encode(['reason' => $reason]),
                'ip_address' => $_SERVER['REMOTE_ADDR']
            ]);
            
            $message = 'تم رفض الإعلان';
            $messageType = 'warning';
        }
    }
}

// Get listing data
$sql = "SELECT l.*, u.id as user_id, u.name as user_name, u.email as user_email, u.phone as user_phone,
               u.user_type, u.is_trusted, u.company_name,
               r.name_ar as region_name, c.name_ar as city_name
        FROM $table l
        LEFT JOIN users u ON l.user_id = u.id
        LEFT JOIN regions r ON l.region_id = r.id
        LEFT JOIN cities c ON l.city_id = c.id
        WHERE l.id = ?";

$listing = $db->fetch($sql, [$id]);

if (!$listing) {
    header('Location: listings.php');
    exit;
}

// Get media
$media = $db->fetchAll("SELECT * FROM $mediaTable WHERE $foreignKey = ? ORDER BY sort_order", [$id]);

$statusLabels = [
    'draft' => 'مسودة',
    'pending_payment' => 'بانتظار الدفع',
    'pending_admin_review' => 'بانتظار المراجعة',
    'active' => 'نشط',
    'expired' => 'منتهي',
    'paused' => 'متوقف',
    'rejected' => 'مرفوض'
];

include 'includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col-12">
            <a href="listings.php" class="btn btn-outline-secondary mb-3">
                <i class="bi bi-arrow-right me-1"></i> العودة للقائمة
            </a>
            <h1 class="h3 mb-0">
                مراجعة <?= $type === 'car' ? 'سيارة' : 'عقار' ?> #<?= $id ?>
            </h1>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-<?= $messageType ?> alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Main Info -->
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">تفاصيل الإعلان</h5>
                    <span class="badge badge-status-<?= $listing['status'] ?> fs-6">
                        <?= $statusLabels[$listing['status']] ?>
                    </span>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <?php if ($type === 'property'): ?>
                        <div class="col-md-6">
                            <label class="text-muted small">نوع العقار</label>
                            <p class="mb-0 fw-bold"><?= PROPERTY_TYPES[$listing['property_type']]['ar'] ?? $listing['property_type'] ?></p>
                        </div>
                        <?php else: ?>
                        <div class="col-md-6">
                            <label class="text-muted small">نوع الاستخدام</label>
                            <p class="mb-0 fw-bold"><?= CAR_USAGE_TYPES[$listing['usage_type']]['ar'] ?? $listing['usage_type'] ?></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">الموديل</label>
                            <p class="mb-0 fw-bold"><?= htmlspecialchars($listing['model'] ?? '') ?></p>
                        </div>
                        <?php endif; ?>
                        
                        <div class="col-md-6">
                            <label class="text-muted small">المنطقة</label>
                            <p class="mb-0"><?= htmlspecialchars($listing['region_name'] ?? '') ?> - <?= htmlspecialchars($listing['city_name'] ?? '') ?></p>
                        </div>
                        
                        <div class="col-md-6">
                            <label class="text-muted small">السعر</label>
                            <?php if ($type === 'car' && (!empty($listing['price_daily']) || !empty($listing['price_weekly']) || !empty($listing['price_monthly']))): ?>
                            <div class="d-flex gap-3">
                                <?php if (!empty($listing['price_daily'])): ?>
                                <div class="text-center">
                                    <span class="fw-bold text-success"><?= number_format($listing['price_daily']) ?> ₪</span>
                                    <br><small class="text-muted">يومي</small>
                                </div>
                                <?php endif; ?>
                                <?php if (!empty($listing['price_weekly'])): ?>
                                <div class="text-center">
                                    <span class="fw-bold text-success"><?= number_format($listing['price_weekly']) ?> ₪</span>
                                    <br><small class="text-muted">أسبوعي</small>
                                </div>
                                <?php endif; ?>
                                <?php if (!empty($listing['price_monthly'])): ?>
                                <div class="text-center">
                                    <span class="fw-bold text-success"><?= number_format($listing['price_monthly']) ?> ₪</span>
                                    <br><small class="text-muted">شهري</small>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php else: ?>
                            <p class="mb-0 fw-bold text-success">
                                <?php if ($listing['price_type'] === 'negotiable'): ?>
                                    قابل للتفاوض
                                <?php elseif ($listing['price_type'] === 'range'): ?>
                                    <?= number_format($listing['price_from']) ?> - <?= number_format($listing['price_to']) ?> ₪
                                <?php else: ?>
                                    <?= number_format($listing['price']) ?> ₪
                                <?php endif; ?>
                            </p>
                            <?php endif; ?>
                        </div>
                        
                        <?php if ($type === 'property'): ?>
                        <div class="col-md-4">
                            <label class="text-muted small">غرف النوم</label>
                            <p class="mb-0"><?= $listing['bedrooms'] ?? '-' ?></p>
                        </div>
                        <div class="col-md-4">
                            <label class="text-muted small">المساحة</label>
                            <p class="mb-0"><?= $listing['area_m2'] ? $listing['area_m2'] . ' م²' : '-' ?></p>
                        </div>
                        <div class="col-md-4">
                            <label class="text-muted small">الطابق</label>
                            <p class="mb-0"><?= $listing['floor'] ?? '-' ?></p>
                        </div>
                        <?php else: ?>
                        <div class="col-md-4">
                            <label class="text-muted small">ناقل الحركة</label>
                            <p class="mb-0"><?= $listing['gearbox'] === 'automatic' ? 'أوتوماتيك' : 'عادي' ?></p>
                        </div>
                        <div class="col-md-4">
                            <label class="text-muted small">مع سائق</label>
                            <p class="mb-0"><?= $listing['with_driver'] ? 'نعم' : 'لا' ?></p>
                        </div>
                        <div class="col-md-4">
                            <label class="text-muted small">لون اللوحة</label>
                            <p class="mb-0"><?= $listing['plate_color'] === 'yellow' ? 'أصفر' : 'أبيض' ?></p>
                        </div>
                        <?php endif; ?>
                        
                        <div class="col-12">
                            <label class="text-muted small">الوصف</label>
                            <p class="mb-0"><?= nl2br(htmlspecialchars($listing['bio'] ?? 'لا يوجد وصف')) ?></p>
                        </div>
                        
                        <div class="col-md-6">
                            <label class="text-muted small">هاتف التواصل</label>
                            <p class="mb-0"><?= htmlspecialchars($listing['contact_phone'] ?? '') ?></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">واتساب</label>
                            <p class="mb-0"><?= htmlspecialchars($listing['whatsapp'] ?? '') ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Media -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">الصور والفيديو (<?= count($media) ?>)</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <?php foreach ($media as $m): ?>
                        <div class="col-md-4">
                            <?php if ($m['media_type'] === 'image'): ?>
                            <img src="<?= htmlspecialchars(UPLOAD_URL . $m['file_path']) ?>" 
                                 class="img-fluid rounded" alt="صورة الإعلان"
                                 style="max-height: 200px; width: 100%; object-fit: cover;">
                            <?php else: ?>
                            <video controls class="w-100 rounded" style="max-height: 200px;">
                                <source src="<?= htmlspecialchars(UPLOAD_URL . $m['file_path']) ?>">
                            </video>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                        <?php if (empty($media)): ?>
                        <div class="col-12 text-center text-muted py-4">
                            لا توجد صور أو فيديوهات
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-md-4">
            <!-- Owner Info -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">معلومات المعلن</h5>
                </div>
                <div class="card-body">
                    <p class="mb-2">
                        <strong><?= htmlspecialchars($listing['user_name']) ?></strong>
                        <?php if ($listing['is_trusted']): ?>
                        <span class="badge bg-success ms-1">موثق</span>
                        <?php endif; ?>
                    </p>
                    <?php if ($listing['company_name']): ?>
                    <p class="mb-2 text-muted"><?= htmlspecialchars($listing['company_name']) ?></p>
                    <?php endif; ?>
                    <p class="mb-1"><i class="bi bi-envelope me-2"></i><?= htmlspecialchars($listing['user_email']) ?></p>
                    <p class="mb-0"><i class="bi bi-phone me-2"></i><?= htmlspecialchars($listing['user_phone']) ?></p>
                    <hr>
                    <p class="mb-0 small text-muted">
                        نوع الحساب: <?= USER_TYPES[$listing['user_type']]['ar'] ?? $listing['user_type'] ?>
                    </p>
                </div>
            </div>

            <!-- Actions -->
            <?php if (in_array($listing['status'], ['pending_admin_review', 'draft', 'rejected', 'paused', 'expired'])): ?>
            <div class="card mb-4">
                <div class="card-header bg-warning">
                    <h5 class="mb-0">إجراءات المراجعة</h5>
                </div>
                <div class="card-body">
                    <form method="POST" id="reviewForm">
                        <?php if ($listing['status'] !== 'active'): ?>
                        <button type="submit" name="action" value="approve" class="btn btn-success w-100 mb-3">
                            <i class="bi bi-check-lg me-1"></i> نشر الإعلان
                        </button>
                        <?php endif; ?>
                        
                        <?php if ($listing['status'] === 'active'): ?>
                        <button type="submit" name="action" value="pause" class="btn btn-warning w-100 mb-3">
                            <i class="bi bi-pause-lg me-1"></i> إيقاف الإعلان
                        </button>
                        <?php endif; ?>
                        
                        <?php if ($listing['status'] !== 'rejected'): ?>
                        <div class="mb-3">
                            <label class="form-label">سبب الرفض</label>
                            <textarea name="reject_reason" class="form-control" rows="3" 
                                      placeholder="يجب إدخال سبب الرفض..."></textarea>
                        </div>
                        <button type="submit" name="action" value="reject" class="btn btn-danger w-100">
                            <i class="bi bi-x-lg me-1"></i> رفض الإعلان
                        </button>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
            <?php elseif ($listing['status'] === 'active'): ?>
            <div class="card mb-4">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">إجراءات الإعلان</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <button type="submit" name="action" value="pause" class="btn btn-warning w-100 mb-3">
                            <i class="bi bi-pause-lg me-1"></i> إيقاف الإعلان
                        </button>
                        <div class="mb-3">
                            <label class="form-label">سبب الرفض</label>
                            <textarea name="reject_reason" class="form-control" rows="3" 
                                      placeholder="يجب إدخال سبب الرفض..."></textarea>
                        </div>
                        <button type="submit" name="action" value="reject" class="btn btn-danger w-100">
                            <i class="bi bi-x-lg me-1"></i> رفض الإعلان
                        </button>
                    </form>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($listing['status'] === 'rejected' && $listing['reject_reason']): ?>
            <div class="card mb-4 border-danger">
                <div class="card-header bg-danger text-white">
                    <h5 class="mb-0">سبب الرفض</h5>
                </div>
                <div class="card-body">
                    <p class="mb-0"><?= nl2br(htmlspecialchars($listing['reject_reason'])) ?></p>
                </div>
            </div>
            <?php endif; ?>

            <!-- Timeline -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">معلومات إضافية</h5>
                </div>
                <div class="card-body">
                    <ul class="list-unstyled mb-0">
                        <li class="mb-2">
                            <small class="text-muted">تاريخ الإنشاء:</small><br>
                            <?= date('Y/m/d H:i', strtotime($listing['created_at'])) ?>
                        </li>
                        <li class="mb-2">
                            <small class="text-muted">آخر تحديث:</small><br>
                            <?= date('Y/m/d H:i', strtotime($listing['updated_at'])) ?>
                        </li>
                        <?php if ($listing['expires_at']): ?>
                        <li class="mb-2">
                            <small class="text-muted">تاريخ الانتهاء:</small><br>
                            <?= date('Y/m/d H:i', strtotime($listing['expires_at'])) ?>
                        </li>
                        <?php endif; ?>
                        <li>
                            <small class="text-muted">المشاهدات:</small><br>
                            <?= number_format($listing['views_count']) ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
