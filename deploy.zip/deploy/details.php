<?php
require_once 'config.php';

// Force login
if (!isset($_SESSION['user']) || !isset($_SESSION['token'])) {
    header('Location: login.php');
    exit;
}

$type = $_GET['type'] ?? 'property';
$id = (int)($_GET['id'] ?? 0);

if (!$id) {
    header('Location: ' . SITE_URL);
    exit;
}

$endpoint = $type === 'car' ? 'cars' : 'properties';
$listing = apiCall("{$endpoint}/{$id}");

if (!$listing['success'] || empty($listing['data'])) {
    header('Location: ' . SITE_URL);
    exit;
}

$data = $listing['data'];
$pageTitle = $data['title'] ?? ($type === 'car' ? 'سيارة للإيجار' : 'عقار للإيجار');

require_once 'includes/header.php';
?>

<div class="bg-white py-4 mb-4 shadow-sm">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= SITE_URL ?>">الرئيسية</a></li>
                <li class="breadcrumb-item"><a href="<?= SITE_URL ?>/<?= $type === 'car' ? 'cars' : 'properties' ?>.php"><?= $type === 'car' ? 'السيارات' : 'العقارات' ?></a></li>
                <li class="breadcrumb-item active"><?= htmlspecialchars($pageTitle) ?></li>
            </ol>
        </nav>
    </div>
</div>

<div class="container py-4">
    <div class="row">
        <div class="col-lg-8 mb-4">
            <div class="details-gallery mb-4">
                <?php 
                $mainImage = !empty($data['media'][0]) ? UPLOAD_URL . $data['media'][0]['file_path'] : 'assets/images/placeholder.jpg';
                ?>
                <img src="<?= $mainImage ?>" id="mainImage" class="details-main-image w-100" alt="<?= htmlspecialchars($pageTitle) ?>">
                
                <?php if (!empty($data['media']) && count($data['media']) > 1): ?>
                    <div class="details-thumbnails">
                        <?php foreach ($data['media'] as $index => $media): ?>
                            <img src="<?= UPLOAD_URL . $media['file_path'] ?>" 
                                 class="gallery-thumb <?= $index === 0 ? 'active' : '' ?>" 
                                 data-src="<?= UPLOAD_URL . $media['file_path'] ?>"
                                 alt="صورة <?= $index + 1 ?>">
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="details-info-card mb-4">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div>
                        <h3 class="mb-2"><?= htmlspecialchars($pageTitle) ?></h3>
                        <p class="text-muted mb-0">
                            <i class="bi bi-geo-alt"></i>
                            <?= $data['city_name_ar'] ?? '' ?>, <?= $data['region_name_ar'] ?? '' ?>
                        </p>
                    </div>
                    <div class="text-end">
                        <?php if ($type === 'car' && (!empty($data['price_daily']) || !empty($data['price_weekly']) || !empty($data['price_monthly']))): ?>
                        <div class="d-flex gap-3 justify-content-end flex-wrap">
                            <?php if (!empty($data['price_daily'])): ?>
                            <div class="text-center">
                                <div class="listing-price fs-5 text-success fw-bold"><?= number_format($data['price_daily']) ?> ₪</div>
                                <small class="text-muted">يومي</small>
                            </div>
                            <?php endif; ?>
                            <?php if (!empty($data['price_weekly'])): ?>
                            <div class="text-center">
                                <div class="listing-price fs-5 text-success fw-bold"><?= number_format($data['price_weekly']) ?> ₪</div>
                                <small class="text-muted">أسبوعي</small>
                            </div>
                            <?php endif; ?>
                            <?php if (!empty($data['price_monthly'])): ?>
                            <div class="text-center">
                                <div class="listing-price fs-5 text-success fw-bold"><?= number_format($data['price_monthly']) ?> ₪</div>
                                <small class="text-muted">شهري</small>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php else: ?>
                        <div class="listing-price fs-4">
                            <?= number_format($data['price'] ?? 0) ?> ₪
                        </div>
                        <small class="text-muted"><?= $type === 'car' ? '/ يومي' : '/ شهري' ?></small>
                        <?php endif; ?>
                    </div>
                </div>
                
                <hr>
                
                <h5>التفاصيل</h5>
                <div class="row g-3 mb-4">
                    <?php if ($type === 'property'): ?>
                        <?php if (!empty($data['bedrooms'])): ?>
                            <div class="col-6 col-md-3">
                                <div class="text-muted small">غرف النوم</div>
                                <div class="fw-bold"><i class="bi bi-door-open text-primary"></i> <?= $data['bedrooms'] ?></div>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($data['bathrooms'])): ?>
                            <div class="col-6 col-md-3">
                                <div class="text-muted small">الحمامات</div>
                                <div class="fw-bold"><i class="bi bi-droplet text-primary"></i> <?= $data['bathrooms'] ?></div>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($data['area_m2'])): ?>
                            <div class="col-6 col-md-3">
                                <div class="text-muted small">المساحة</div>
                                <div class="fw-bold"><i class="bi bi-arrows-angle-expand text-primary"></i> <?= $data['area_m2'] ?> م²</div>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($data['floor'])): ?>
                            <div class="col-6 col-md-3">
                                <div class="text-muted small">الطابق</div>
                                <div class="fw-bold"><i class="bi bi-layers text-primary"></i> <?= $data['floor'] ?></div>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if (!empty($data['model'])): ?>
                            <div class="col-6 col-md-3">
                                <div class="text-muted small">الموديل</div>
                                <div class="fw-bold"><i class="bi bi-car-front text-primary"></i> <?= $data['model'] ?></div>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($data['year'])): ?>
                            <div class="col-6 col-md-3">
                                <div class="text-muted small">سنة الصنع</div>
                                <div class="fw-bold"><i class="bi bi-calendar text-primary"></i> <?= $data['year'] ?></div>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($data['gearbox'])): ?>
                            <div class="col-6 col-md-3">
                                <div class="text-muted small">ناقل الحركة</div>
                                <div class="fw-bold"><i class="bi bi-gear text-primary"></i> <?= $data['gearbox'] == 'automatic' ? 'أوتوماتيك' : 'عادي' ?></div>
                            </div>
                        <?php endif; ?>
                        <?php if (isset($data['with_driver'])): ?>
                            <div class="col-6 col-md-3">
                                <div class="text-muted small">مع سائق</div>
                                <div class="fw-bold"><i class="bi bi-person text-primary"></i> <?= $data['with_driver'] ? 'نعم' : 'لا' ?></div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($data['bio'])): ?>
                    <h5>الوصف</h5>
                    <p class="mb-0"><?= nl2br(htmlspecialchars($data['bio'])) ?></p>
                <?php endif; ?>
            </div>
            
            <div class="details-info-card">
                <h5>الموقع</h5>
                <p class="mb-0">
                    <i class="bi bi-geo-alt text-primary"></i>
                    <?= $data['address_text'] ?? '' ?>
                    <?= $data['city_name_ar'] ?? '' ?>, <?= $data['region_name_ar'] ?? '' ?>
                </p>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="owner-card mb-4">
                <h5 class="mb-3">المعلن</h5>
                <div class="d-flex align-items-center mb-3">
                    <div class="owner-avatar me-3">
                        <?= mb_substr($data['owner_name'] ?? 'م', 0, 1) ?>
                    </div>
                    <div>
                        <h6 class="mb-0">
                            <?= htmlspecialchars($data['owner_name'] ?? 'المعلن') ?>
                            <?php if (!empty($data['owner_is_trusted'])): ?>
                                <i class="bi bi-patch-check-fill trusted-badge"></i>
                            <?php endif; ?>
                        </h6>
                        <?php if (!empty($data['owner_company'])): ?>
                            <small class="text-muted"><?= htmlspecialchars($data['owner_company']) ?></small>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="d-grid gap-2">
                    <a href="tel:<?= $data['contact_phone'] ?? '' ?>" class="btn btn-primary btn-lg">
                        <i class="bi bi-telephone"></i> اتصال
                    </a>
                    <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $data['whatsapp'] ?? $data['contact_phone'] ?? '') ?>?text=<?= urlencode('مرحباً، أنا مهتم بإعلانك: ' . $pageTitle) ?>" 
                       class="btn btn-success btn-lg" target="_blank">
                        <i class="bi bi-whatsapp"></i> واتساب
                    </a>
                </div>
            </div>
            
            <div class="details-info-card">
                <h5>مشاركة الإعلان</h5>
                <div class="d-flex gap-2">
                    <button onclick="shareListing('<?= htmlspecialchars($pageTitle) ?>', window.location.href)" class="btn btn-outline-primary flex-grow-1">
                        <i class="bi bi-share"></i> مشاركة
                    </button>
                    <button class="btn btn-outline-danger favorite-btn" data-id="<?= $id ?>" data-type="<?= $type ?>">
                        <i class="bi bi-heart"></i>
                    </button>
                </div>
            </div>
            
            <div class="mt-4">
                <div class="alert alert-info">
                    <i class="bi bi-info-circle"></i>
                    <strong>نصيحة:</strong> استخدم تطبيق Rento Go للحصول على أفضل تجربة وميزات إضافية!
                    <div class="mt-2">
                        <a href="download.php" class="btn btn-sm btn-primary">حمّل التطبيق</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
