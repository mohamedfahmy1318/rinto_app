<?php
$pageTitle = 'العقارات';
require_once 'config.php';

// Force login
if (!isset($_SESSION['user']) || !isset($_SESSION['token'])) {
    header('Location: login.php');
    exit;
}

$page = (int)($_GET['page'] ?? 1);
$params = http_build_query([
    'page' => $page,
    'per_page' => 12,
    'region_id' => $_GET['region_id'] ?? '',
    'city_id' => $_GET['city_id'] ?? '',
    'property_type' => $_GET['property_type'] ?? '',
    'price_min' => $_GET['price_min'] ?? '',
    'price_max' => $_GET['price_max'] ?? '',
    'bedrooms' => $_GET['bedrooms'] ?? '',
    'search' => $_GET['search'] ?? ''
]);

$properties = apiCall('properties?' . $params);
$regions = apiCall('regions');

require_once 'includes/header.php';
?>

<div class="bg-white py-4 mb-4 shadow-sm">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= SITE_URL ?>">الرئيسية</a></li>
                <li class="breadcrumb-item active">العقارات</li>
            </ol>
        </nav>
    </div>
</div>

<div class="container py-4">
    <div class="row">
        <div class="col-lg-3 mb-4">
            <div class="filters-card">
                <h5><i class="bi bi-funnel"></i> تصفية النتائج</h5>
                
                <form id="filterForm" method="GET">
                    <div class="filter-group">
                        <label>نوع العقار</label>
                        <select name="property_type" class="form-select auto-submit">
                            <option value="">الكل</option>
                            <option value="apartment" <?= ($_GET['property_type'] ?? '') == 'apartment' ? 'selected' : '' ?>>شقق سكنية</option>
                            <option value="villa_chalet" <?= ($_GET['property_type'] ?? '') == 'villa_chalet' ? 'selected' : '' ?>>فلل وشاليهات</option>
                            <option value="shop_office" <?= ($_GET['property_type'] ?? '') == 'shop_office' ? 'selected' : '' ?>>محلات ومكاتب</option>
                            <option value="student_housing" <?= ($_GET['property_type'] ?? '') == 'student_housing' ? 'selected' : '' ?>>سكن طلاب</option>
                            <option value="land" <?= ($_GET['property_type'] ?? '') == 'land' ? 'selected' : '' ?>>أراضي</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>المنطقة</label>
                        <select name="region_id" class="form-select auto-submit">
                            <option value="">كل المناطق</option>
                            <?php if (!empty($regions['data'])): ?>
                                <?php foreach ($regions['data'] as $region): ?>
                                    <option value="<?= $region['id'] ?>" <?= ($_GET['region_id'] ?? '') == $region['id'] ? 'selected' : '' ?>>
                                        <?= $region['name_ar'] ?>
                                    </option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>عدد الغرف</label>
                        <select name="bedrooms" class="form-select auto-submit">
                            <option value="">الكل</option>
                            <option value="1" <?= ($_GET['bedrooms'] ?? '') == '1' ? 'selected' : '' ?>>1+</option>
                            <option value="2" <?= ($_GET['bedrooms'] ?? '') == '2' ? 'selected' : '' ?>>2+</option>
                            <option value="3" <?= ($_GET['bedrooms'] ?? '') == '3' ? 'selected' : '' ?>>3+</option>
                            <option value="4" <?= ($_GET['bedrooms'] ?? '') == '4' ? 'selected' : '' ?>>4+</option>
                            <option value="5" <?= ($_GET['bedrooms'] ?? '') == '5' ? 'selected' : '' ?>>5+</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>السعر (₪)</label>
                        <div class="row g-2">
                            <div class="col-6">
                                <input type="number" id="priceMin" name="price_min" class="form-control" placeholder="من" value="<?= $_GET['price_min'] ?? '' ?>">
                            </div>
                            <div class="col-6">
                                <input type="number" id="priceMax" name="price_max" class="form-control" placeholder="إلى" value="<?= $_GET['price_max'] ?? '' ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="filter-group">
                        <label>بحث</label>
                        <input type="text" name="search" class="form-control" placeholder="كلمة البحث..." value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-search"></i> بحث
                    </button>
                    
                    <a href="properties.php" class="btn btn-outline-secondary w-100 mt-2">
                        <i class="bi bi-x-circle"></i> مسح الفلاتر
                    </a>
                </form>
            </div>
        </div>
        
        <div class="col-lg-9">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="mb-0">
                    العقارات
                    <?php if (!empty($properties['pagination']['total'])): ?>
                        <small class="text-muted">(<?= $properties['pagination']['total'] ?> نتيجة)</small>
                    <?php endif; ?>
                </h4>
            </div>
            
            <div class="marketplace-grid" id="listingsContainer">
                <?php if (!empty($properties['data'])): ?>
                    <?php foreach ($properties['data'] as $property): ?>
                        <a href="details.php?type=property&id=<?= $property['id'] ?>" class="text-decoration-none">
                            <div class="listing-card <?= !empty($property['badge']) ? 'featured-listing' : '' ?>">
                                <div class="card-img-container">
                                    <img src="<?= $property['thumbnail'] ?? 'assets/images/placeholder.jpg' ?>" class="card-img-top" alt="<?= htmlspecialchars($property['title'] ?? 'عقار') ?>">
                                    <?php if (!empty($property['badge'])): ?>
                                    <span class="featured-badge badge-<?= $property['badge'] ?>">
                                        <i class="bi bi-star-fill"></i>
                                        <?= $property['badge'] === 'gold' ? 'ذهبي' : ($property['badge'] === 'silver' ? 'فضي' : 'برونزي') ?>
                                    </span>
                                    <?php endif; ?>
                                    <button class="favorite-btn" onclick="event.preventDefault();" data-id="<?= $property['id'] ?>" data-type="property">
                                        <i class="bi bi-heart"></i>
                                    </button>
                                </div>
                                <div class="card-body">
                                    <div class="listing-price">
                                        <?= number_format($property['price'] ?? 0) ?> ₪
                                    </div>
                                    <h5 class="listing-title"><?= htmlspecialchars($property['title'] ?? 'عقار للإيجار') ?></h5>
                                    <div class="listing-location">
                                        <i class="bi bi-geo-alt"></i>
                                        <?= $property['city_name_ar'] ?? '' ?>
                                    </div>
                                    <div class="listing-features">
                                        <?php if (!empty($property['bedrooms'])): ?>
                                            <span><i class="bi bi-door-open"></i> <?= $property['bedrooms'] ?></span>
                                        <?php endif; ?>
                                        <?php if (!empty($property['area_m2'])): ?>
                                            <span><i class="bi bi-arrows-angle-expand"></i> <?= $property['area_m2'] ?>م</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="col-12">
                        <div class="empty-state">
                            <i class="bi bi-building"></i>
                            <h5>لا توجد نتائج</h5>
                            <p>جرب تغيير معايير البحث</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php if (!empty($properties['pagination']) && $properties['pagination']['total_pages'] > 1): ?>
                <nav class="mt-4">
                    <ul class="pagination justify-content-center">
                        <?php for ($i = 1; $i <= $properties['pagination']['total_pages']; $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
