<?php
$pageTitle = 'السيارات';
require_once 'config.php';

// Force login
if (!isset($_SESSION['user']) || !isset($_SESSION['token'])) {
    header('Location: login.php');
    exit;
}

$page = (int)($_GET['page'] ?? 1);
$params = http_build_query([
    'page' => $page,
    'per_page' => 12,
    'region_id' => $_GET['region_id'] ?? '',
    'city_id' => $_GET['city_id'] ?? '',
    'usage_type' => $_GET['usage_type'] ?? '',
    'price_min' => $_GET['price_min'] ?? '',
    'price_max' => $_GET['price_max'] ?? '',
    'search' => $_GET['search'] ?? ''
]);

$cars = apiCall('cars?' . $params);
$regions = apiCall('regions');

require_once 'includes/header.php';
?>

<div class="bg-white py-4 mb-4 shadow-sm">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= SITE_URL ?>">الرئيسية</a></li>
                <li class="breadcrumb-item active">السيارات</li>
            </ol>
        </nav>
    </div>
</div>

<div class="container py-4">
    <div class="row">
        <div class="col-lg-3 mb-4">
            <div class="filters-card">
                <h5><i class="bi bi-funnel"></i> تصفية النتائج</h5>
                
                <form id="filterForm" method="GET">
                    <div class="filter-group">
                        <label>نوع الاستخدام</label>
                        <select name="usage_type" class="form-select auto-submit">
                            <option value="">الكل</option>
                            <option value="daily" <?= ($_GET['usage_type'] ?? '') == 'daily' ? 'selected' : '' ?>>استخدام يومي</option>
                            <option value="wedding" <?= ($_GET['usage_type'] ?? '') == 'wedding' ? 'selected' : '' ?>>زفة أعراس</option>
                            <option value="tourism" <?= ($_GET['usage_type'] ?? '') == 'tourism' ? 'selected' : '' ?>>سياحية</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>المنطقة</label>
                        <select name="region_id" class="form-select auto-submit">
                            <option value="">كل المناطق</option>
                            <?php if (!empty($regions['data'])): ?>
                                <?php foreach ($regions['data'] as $region): ?>
                                    <option value="<?= $region['id'] ?>" <?= ($_GET['region_id'] ?? '') == $region['id'] ? 'selected' : '' ?>>
                                        <?= $region['name_ar'] ?>
                                    </option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>السعر اليومي (₪)</label>
                        <div class="row g-2">
                            <div class="col-6">
                                <input type="number" id="priceMin" name="price_min" class="form-control" placeholder="من" value="<?= $_GET['price_min'] ?? '' ?>">
                            </div>
                            <div class="col-6">
                                <input type="number" id="priceMax" name="price_max" class="form-control" placeholder="إلى" value="<?= $_GET['price_max'] ?? '' ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="filter-group">
                        <label>بحث</label>
                        <input type="text" name="search" class="form-control" placeholder="ماركة أو موديل..." value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-search"></i> بحث
                    </button>
                    
                    <a href="cars.php" class="btn btn-outline-secondary w-100 mt-2">
                        <i class="bi bi-x-circle"></i> مسح الفلاتر
                    </a>
                </form>
            </div>
        </div>
        
        <div class="col-lg-9">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="mb-0">
                    السيارات
                    <?php if (!empty($cars['pagination']['total'])): ?>
                        <small class="text-muted">(<?= $cars['pagination']['total'] ?> نتيجة)</small>
                    <?php endif; ?>
                </h4>
            </div>
            
            <div class="marketplace-grid" id="listingsContainer">
                <?php if (!empty($cars['data'])): ?>
                    <?php foreach ($cars['data'] as $car): ?>
                        <a href="details.php?type=car&id=<?= $car['id'] ?>" class="text-decoration-none">
                            <div class="listing-card <?= !empty($car['badge']) ? 'featured-listing' : '' ?>">
                                <div class="card-img-container">
                                    <img src="<?= $car['thumbnail'] ?? 'assets/images/car-placeholder.jpg' ?>" class="card-img-top" alt="<?= htmlspecialchars($car['title'] ?? 'سيارة') ?>">
                                    <?php if (!empty($car['badge'])): ?>
                                    <span class="featured-badge badge-<?= $car['badge'] ?>">
                                        <i class="bi bi-star-fill"></i>
                                        <?= $car['badge'] === 'gold' ? 'ذهبي' : ($car['badge'] === 'silver' ? 'فضي' : 'برونزي') ?>
                                    </span>
                                    <?php endif; ?>
                                    <button class="favorite-btn" onclick="event.preventDefault();" data-id="<?= $car['id'] ?>" data-type="car">
                                        <i class="bi bi-heart"></i>
                                    </button>
                                </div>
                                <div class="card-body">
                                    <div class="listing-price">
                                        <?php if (!empty($car['price_daily'])): ?>
                                            <?= number_format($car['price_daily']) ?> ₪
                                        <?php elseif (!empty($car['price_weekly'])): ?>
                                            <?= number_format($car['price_weekly']) ?> ₪
                                        <?php elseif (!empty($car['price_monthly'])): ?>
                                            <?= number_format($car['price_monthly']) ?> ₪
                                        <?php else: ?>
                                            <?= number_format($car['price'] ?? 0) ?> ₪
                                        <?php endif; ?>
                                    </div>
                                    <h5 class="listing-title"><?= htmlspecialchars($car['model'] ?? 'سيارة للإيجار') ?></h5>
                                    <div class="listing-location">
                                        <i class="bi bi-geo-alt"></i>
                                        <?= $car['city_name_ar'] ?? '' ?>
                                    </div>
                                    <div class="listing-features">
                                        <?php if (!empty($car['year'])): ?>
                                            <span><i class="bi bi-calendar"></i> <?= $car['year'] ?></span>
                                        <?php endif; ?>
                                        <?php if (!empty($car['gearbox'])): ?>
                                            <span><i class="bi bi-gear"></i> <?= $car['gearbox'] == 'automatic' ? 'أوتو' : 'عادي' ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="col-12">
                        <div class="empty-state">
                            <i class="bi bi-car-front"></i>
                            <h5>لا توجد نتائج</h5>
                            <p>جرب تغيير معايير البحث</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php if (!empty($cars['pagination']) && $cars['pagination']['total_pages'] > 1): ?>
                <nav class="mt-4">
                    <ul class="pagination justify-content-center">
                        <?php for ($i = 1; $i <= $cars['pagination']['total_pages']; $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
