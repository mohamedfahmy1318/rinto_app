-- Rento Go Database Schema
-- MySQL Database

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- Create database
CREATE DATABASE IF NOT EXISTS `rento_go` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `rento_go`;

-- ============================================
-- USERS & AUTHENTICATION
-- ============================================

CREATE TABLE `users` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `company_name` VARCHAR(255) NULL,
    `email` VARCHAR(255) NOT NULL UNIQUE,
    `phone` VARCHAR(20) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `user_type` ENUM('renter', 'owner', 'office', 'car_lessor') NOT NULL DEFAULT 'renter',
    `profile_image` VARCHAR(500) NULL,
    `is_verified_phone` TINYINT(1) DEFAULT 0,
    `is_verified_email` TINYINT(1) DEFAULT 0,
    `is_trusted` TINYINT(1) DEFAULT 0,
    `trusted_until` DATE NULL,
    `is_active` TINYINT(1) DEFAULT 1,
    `is_blocked` TINYINT(1) DEFAULT 0,
    `preferred_language` ENUM('ar', 'en', 'he') DEFAULT 'ar',
    `fcm_token` VARCHAR(500) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_user_type` (`user_type`),
    INDEX `idx_phone` (`phone`),
    INDEX `idx_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `admin_users` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `role` ENUM('super_admin', 'admin', 'moderator') DEFAULT 'admin',
    `is_active` TINYINT(1) DEFAULT 1,
    `last_login` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `otp_codes` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NULL,
    `phone` VARCHAR(20) NULL,
    `email` VARCHAR(255) NULL,
    `code` VARCHAR(6) NOT NULL,
    `type` ENUM('phone', 'email', 'password_reset') NOT NULL,
    `expires_at` TIMESTAMP NOT NULL,
    `is_used` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- REGIONS & CITIES
-- ============================================

CREATE TABLE `regions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name_ar` VARCHAR(255) NOT NULL,
    `name_en` VARCHAR(255) NOT NULL,
    `name_he` VARCHAR(255) NOT NULL,
    `slug` VARCHAR(100) NOT NULL UNIQUE,
    `is_active` TINYINT(1) DEFAULT 1,
    `sort_order` INT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `cities` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `region_id` INT UNSIGNED NOT NULL,
    `name_ar` VARCHAR(255) NOT NULL,
    `name_en` VARCHAR(255) NOT NULL,
    `name_he` VARCHAR(255) NOT NULL,
    `slug` VARCHAR(100) NOT NULL,
    `is_active` TINYINT(1) DEFAULT 1,
    `sort_order` INT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`region_id`) REFERENCES `regions`(`id`) ON DELETE CASCADE,
    UNIQUE KEY `unique_city_region` (`region_id`, `slug`),
    INDEX `idx_region` (`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- PROPERTIES (Real Estate Listings)
-- ============================================

CREATE TABLE `properties` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `title` VARCHAR(255) NULL,
    `property_type` ENUM('apartment', 'shop_office', 'villa_chalet', 'student_housing', 'land') NOT NULL,
    `region_id` INT UNSIGNED NOT NULL,
    `city_id` INT UNSIGNED NOT NULL,
    `address_text` VARCHAR(500) NULL,
    `price_type` ENUM('fixed', 'range', 'negotiable') DEFAULT 'fixed',
    `price` DECIMAL(12, 2) NULL,
    `price_from` DECIMAL(12, 2) NULL,
    `price_to` DECIMAL(12, 2) NULL,
    `currency` VARCHAR(10) DEFAULT 'ILS',
    `bedrooms` INT NULL,
    `bathrooms` INT NULL,
    `floor` INT NULL,
    `area_m2` DECIMAL(10, 2) NULL,
    `bio` TEXT NULL,
    `language` ENUM('ar', 'he') DEFAULT 'ar',
    `contact_phone` VARCHAR(20) NOT NULL,
    `whatsapp` VARCHAR(20) NULL,
    `status` ENUM('draft', 'pending_payment', 'pending_admin_review', 'active', 'expired', 'paused', 'rejected') DEFAULT 'draft',
    `reject_reason` TEXT NULL,
    `views_count` INT DEFAULT 0,
    `subscription_id` INT UNSIGNED NULL,
    `expires_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`region_id`) REFERENCES `regions`(`id`),
    FOREIGN KEY (`city_id`) REFERENCES `cities`(`id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_property_type` (`property_type`),
    INDEX `idx_region_city` (`region_id`, `city_id`),
    INDEX `idx_user` (`user_id`),
    INDEX `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `property_media` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `property_id` INT UNSIGNED NOT NULL,
    `media_type` ENUM('image', 'video') DEFAULT 'image',
    `file_path` VARCHAR(500) NOT NULL,
    `file_name` VARCHAR(255) NULL,
    `sort_order` INT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`property_id`) REFERENCES `properties`(`id`) ON DELETE CASCADE,
    INDEX `idx_property` (`property_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- CARS (Vehicle Listings)
-- ============================================

CREATE TABLE `cars` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `title` VARCHAR(255) NULL,
    `usage_type` ENUM('daily', 'wedding', 'tourism') NOT NULL,
    `model` VARCHAR(255) NOT NULL,
    `year` INT NULL,
    `gearbox` ENUM('manual', 'automatic') DEFAULT 'automatic',
    `with_driver` TINYINT(1) DEFAULT 0,
    `duration_type` ENUM('daily', 'weekly', 'monthly') DEFAULT 'daily',
    `plate_color` ENUM('yellow', 'white') DEFAULT 'yellow',
    `region_id` INT UNSIGNED NOT NULL,
    `city_id` INT UNSIGNED NOT NULL,
    `address_text` VARCHAR(500) NULL,
    `price_type` ENUM('fixed', 'range', 'negotiable') DEFAULT 'fixed',
    `price` DECIMAL(12, 2) NULL,
    `price_from` DECIMAL(12, 2) NULL,
    `price_to` DECIMAL(12, 2) NULL,
    `currency` VARCHAR(10) DEFAULT 'ILS',
    `bio` TEXT NULL,
    `language` ENUM('ar', 'he') DEFAULT 'ar',
    `contact_phone` VARCHAR(20) NOT NULL,
    `whatsapp` VARCHAR(20) NULL,
    `status` ENUM('draft', 'pending_payment', 'pending_admin_review', 'active', 'expired', 'paused', 'rejected') DEFAULT 'draft',
    `reject_reason` TEXT NULL,
    `views_count` INT DEFAULT 0,
    `subscription_id` INT UNSIGNED NULL,
    `expires_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`region_id`) REFERENCES `regions`(`id`),
    FOREIGN KEY (`city_id`) REFERENCES `cities`(`id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_usage_type` (`usage_type`),
    INDEX `idx_region_city` (`region_id`, `city_id`),
    INDEX `idx_user` (`user_id`),
    INDEX `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `car_media` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `car_id` INT UNSIGNED NOT NULL,
    `media_type` ENUM('image', 'video') DEFAULT 'image',
    `file_path` VARCHAR(500) NOT NULL,
    `file_name` VARCHAR(255) NULL,
    `sort_order` INT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`car_id`) REFERENCES `cars`(`id`) ON DELETE CASCADE,
    INDEX `idx_car` (`car_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- PLANS & SUBSCRIPTIONS
-- ============================================

CREATE TABLE `plans` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `category` ENUM('properties', 'cars') NOT NULL,
    `name_ar` VARCHAR(255) NOT NULL,
    `name_en` VARCHAR(255) NOT NULL,
    `name_he` VARCHAR(255) NOT NULL,
    `description_ar` TEXT NULL,
    `description_en` TEXT NULL,
    `description_he` TEXT NULL,
    `plan_type` ENUM('single', 'package') DEFAULT 'single',
    `property_type` ENUM('apartment', 'shop_office', 'villa_chalet', 'student_housing', 'land') NULL,
    `car_usage_type` ENUM('daily', 'wedding', 'tourism') NULL,
    `listings_count` INT NULL,
    `is_unlimited` TINYINT(1) DEFAULT 0,
    `duration_days` INT DEFAULT 30,
    `price` DECIMAL(10, 2) NOT NULL,
    `original_price` DECIMAL(10, 2) NULL,
    `discount_percent` INT NULL,
    `currency` VARCHAR(10) DEFAULT 'ILS',
    `badge` ENUM('bronze', 'silver', 'gold') NULL,
    `is_featured` TINYINT(1) DEFAULT 0,
    `is_active` TINYINT(1) DEFAULT 1,
    `sort_order` INT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_category` (`category`),
    INDEX `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `subscriptions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `plan_id` INT UNSIGNED NOT NULL,
    `listings_used` INT DEFAULT 0,
    `listings_limit` INT NULL,
    `is_unlimited` TINYINT(1) DEFAULT 0,
    `status` ENUM('active', 'expired', 'cancelled') DEFAULT 'active',
    `starts_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `expires_at` TIMESTAMP NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`plan_id`) REFERENCES `plans`(`id`),
    INDEX `idx_user` (`user_id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- PAYMENTS
-- ============================================

CREATE TABLE `payments` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `plan_id` INT UNSIGNED NOT NULL,
    `subscription_id` INT UNSIGNED NULL,
    `amount` DECIMAL(10, 2) NOT NULL,
    `currency` VARCHAR(10) DEFAULT 'ILS',
    `platform` ENUM('ios', 'android', 'web') NOT NULL,
    `transaction_id` VARCHAR(255) NULL,
    `receipt_data` TEXT NULL,
    `status` ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    `verified_at` TIMESTAMP NULL,
    `verified_by` INT UNSIGNED NULL,
    `notes` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`plan_id`) REFERENCES `plans`(`id`),
    FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`verified_by`) REFERENCES `admin_users`(`id`) ON DELETE SET NULL,
    INDEX `idx_user` (`user_id`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- FAVORITES
-- ============================================

CREATE TABLE `favorites` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `listing_type` ENUM('property', 'car') NOT NULL,
    `listing_id` INT UNSIGNED NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    UNIQUE KEY `unique_favorite` (`user_id`, `listing_type`, `listing_id`),
    INDEX `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- REPORTS (User Reports)
-- ============================================

CREATE TABLE `reports` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `reporter_id` INT UNSIGNED NOT NULL,
    `listing_type` ENUM('property', 'car') NOT NULL,
    `listing_id` INT UNSIGNED NOT NULL,
    `reported_user_id` INT UNSIGNED NOT NULL,
    `reason` TEXT NOT NULL,
    `screenshot` VARCHAR(500) NULL,
    `status` ENUM('pending', 'reviewed', 'resolved', 'dismissed') DEFAULT 'pending',
    `admin_notes` TEXT NULL,
    `reviewed_by` INT UNSIGNED NULL,
    `reviewed_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`reporter_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`reported_user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`reviewed_by`) REFERENCES `admin_users`(`id`) ON DELETE SET NULL,
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- NOTIFICATIONS
-- ============================================

CREATE TABLE `notifications` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `title_ar` VARCHAR(255) NOT NULL,
    `title_en` VARCHAR(255) NOT NULL,
    `title_he` VARCHAR(255) NOT NULL,
    `body_ar` TEXT NULL,
    `body_en` TEXT NULL,
    `body_he` TEXT NULL,
    `type` ENUM('listing_approved', 'listing_rejected', 'subscription_expiring', 'subscription_expired', 'general') NOT NULL,
    `data` JSON NULL,
    `is_read` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_user` (`user_id`),
    INDEX `idx_read` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- CMS PAGES
-- ============================================

CREATE TABLE `cms_pages` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `slug` VARCHAR(100) NOT NULL UNIQUE,
    `title_ar` VARCHAR(255) NOT NULL,
    `title_en` VARCHAR(255) NOT NULL,
    `title_he` VARCHAR(255) NOT NULL,
    `content_ar` LONGTEXT NULL,
    `content_en` LONGTEXT NULL,
    `content_he` LONGTEXT NULL,
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- AUDIT LOGS
-- ============================================

CREATE TABLE `audit_logs` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `admin_id` INT UNSIGNED NULL,
    `action` VARCHAR(100) NOT NULL,
    `entity_type` VARCHAR(100) NULL,
    `entity_id` INT UNSIGNED NULL,
    `old_data` JSON NULL,
    `new_data` JSON NULL,
    `ip_address` VARCHAR(45) NULL,
    `user_agent` VARCHAR(500) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`admin_id`) REFERENCES `admin_users`(`id`) ON DELETE SET NULL,
    INDEX `idx_admin` (`admin_id`),
    INDEX `idx_action` (`action`),
    INDEX `idx_entity` (`entity_type`, `entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- MESSAGES (Internal Chat - Optional)
-- ============================================

CREATE TABLE `conversations` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user1_id` INT UNSIGNED NOT NULL,
    `user2_id` INT UNSIGNED NOT NULL,
    `listing_type` ENUM('property', 'car') NULL,
    `listing_id` INT UNSIGNED NULL,
    `last_message_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user1_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user2_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_users` (`user1_id`, `user2_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `messages` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `conversation_id` INT UNSIGNED NOT NULL,
    `sender_id` INT UNSIGNED NOT NULL,
    `message` TEXT NOT NULL,
    `is_read` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`conversation_id`) REFERENCES `conversations`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`sender_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_conversation` (`conversation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- SEED DATA
-- ============================================

-- Default Admin User (password: admin123)
INSERT INTO `admin_users` (`name`, `email`, `password`, `role`) VALUES
('Super Admin', 'admin@rentogo.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'super_admin');

-- Regions
INSERT INTO `regions` (`name_ar`, `name_en`, `name_he`, `slug`, `sort_order`) VALUES
('الضفة الغربية', 'West Bank', 'הגדה המערבית', 'west-bank', 1),
('القدس', 'Jerusalem', 'ירושלים', 'jerusalem', 2),
('الداخل', 'Israel', 'ישראל', 'israel', 3),
('النقب', 'Negev', 'הנגב', 'negev', 4);

-- Cities for West Bank
INSERT INTO `cities` (`region_id`, `name_ar`, `name_en`, `name_he`, `slug`, `sort_order`) VALUES
(1, 'رام الله', 'Ramallah', 'רמאללה', 'ramallah', 1),
(1, 'نابلس', 'Nablus', 'שכם', 'nablus', 2),
(1, 'الخليل', 'Hebron', 'חברון', 'hebron', 3),
(1, 'بيت لحم', 'Bethlehem', 'בית לחם', 'bethlehem', 4),
(1, 'جنين', 'Jenin', 'ג׳נין', 'jenin', 5),
(1, 'طولكرم', 'Tulkarm', 'טול כרם', 'tulkarm', 6),
(1, 'قلقيلية', 'Qalqilya', 'קלקיליה', 'qalqilya', 7),
(1, 'سلفيت', 'Salfit', 'סלפית', 'salfit', 8),
(1, 'طوباس', 'Tubas', 'טובאס', 'tubas', 9),
(1, 'أريحا', 'Jericho', 'יריחו', 'jericho', 10);

-- Cities for Jerusalem
INSERT INTO `cities` (`region_id`, `name_ar`, `name_en`, `name_he`, `slug`, `sort_order`) VALUES
(2, 'القدس', 'Jerusalem', 'ירושלים', 'jerusalem-city', 1),
(2, 'العيزرية', 'Al-Eizariya', 'אל-עיזריה', 'al-eizariya', 2),
(2, 'أبو ديس', 'Abu Dis', 'אבו דיס', 'abu-dis', 3);

-- Cities for Israel (Interior)
INSERT INTO `cities` (`region_id`, `name_ar`, `name_en`, `name_he`, `slug`, `sort_order`) VALUES
(3, 'حيفا', 'Haifa', 'חיפה', 'haifa', 1),
(3, 'يافا', 'Jaffa', 'יפו', 'jaffa', 2),
(3, 'الناصرة', 'Nazareth', 'נצרת', 'nazareth', 3),
(3, 'عكا', 'Acre', 'עכו', 'acre', 4),
(3, 'اللد', 'Lod', 'לוד', 'lod', 5),
(3, 'الرملة', 'Ramla', 'רמלה', 'ramla', 6);

-- Cities for Negev
INSERT INTO `cities` (`region_id`, `name_ar`, `name_en`, `name_he`, `slug`, `sort_order`) VALUES
(4, 'بئر السبع', 'Beersheba', 'באר שבע', 'beersheba', 1),
(4, 'رهط', 'Rahat', 'רהט', 'rahat', 2);

-- Sample Plans for Properties
INSERT INTO `plans` (`category`, `name_ar`, `name_en`, `name_he`, `plan_type`, `property_type`, `listings_count`, `duration_days`, `price`, `original_price`, `discount_percent`, `sort_order`) VALUES
('properties', 'إعلان شقة واحد', 'Single Apartment Ad', 'מודעת דירה בודדת', 'single', 'apartment', 1, 30, 50.00, NULL, NULL, 1),
('properties', 'إعلان فيلا واحد', 'Single Villa Ad', 'מודעת וילה בודדת', 'single', 'villa_chalet', 1, 30, 100.00, NULL, NULL, 2),
('properties', 'إعلان محل واحد', 'Single Shop Ad', 'מודעת חנות בודדת', 'single', 'shop_office', 1, 30, 75.00, NULL, NULL, 3),
('properties', 'باقة برونزية', 'Bronze Package', 'חבילת ברונזה', 'package', NULL, 5, 30, 200.00, 250.00, 20, 4),
('properties', 'باقة فضية', 'Silver Package', 'חבילת כסף', 'package', NULL, 10, 30, 350.00, 500.00, 30, 5),
('properties', 'باقة ذهبية', 'Gold Package', 'חבילת זהב', 'package', NULL, NULL, 30, 500.00, 750.00, 33, 6);

-- Update Gold package to unlimited
UPDATE `plans` SET `is_unlimited` = 1, `badge` = 'gold', `is_featured` = 1 WHERE `name_en` = 'Gold Package';
UPDATE `plans` SET `badge` = 'silver' WHERE `name_en` = 'Silver Package';
UPDATE `plans` SET `badge` = 'bronze' WHERE `name_en` = 'Bronze Package';

-- Sample Plans for Cars
INSERT INTO `plans` (`category`, `name_ar`, `name_en`, `name_he`, `plan_type`, `car_usage_type`, `listings_count`, `duration_days`, `price`, `original_price`, `discount_percent`, `sort_order`) VALUES
('cars', 'إعلان سيارة يومية', 'Daily Car Ad', 'מודעת רכב יומית', 'single', 'daily', 1, 30, 40.00, NULL, NULL, 1),
('cars', 'إعلان سيارة أعراس', 'Wedding Car Ad', 'מודעת רכב לחתונות', 'single', 'wedding', 1, 30, 60.00, NULL, NULL, 2),
('cars', 'إعلان سيارة سياحية', 'Tourism Car Ad', 'מודעת רכב לתיירות', 'single', 'tourism', 1, 30, 80.00, NULL, NULL, 3),
('cars', 'باقة سيارات برونزية', 'Bronze Cars Package', 'חבילת רכבים ברונזה', 'package', NULL, 5, 30, 150.00, 200.00, 25, 4),
('cars', 'باقة سيارات فضية', 'Silver Cars Package', 'חבילת רכבים כסף', 'package', NULL, 10, 30, 280.00, 400.00, 30, 5),
('cars', 'باقة سيارات ذهبية', 'Gold Cars Package', 'חבילת רכבים זהב', 'package', NULL, NULL, 30, 400.00, 600.00, 33, 6);

-- Update car packages badges
UPDATE `plans` SET `is_unlimited` = 1, `badge` = 'gold', `is_featured` = 1 WHERE `name_en` = 'Gold Cars Package';
UPDATE `plans` SET `badge` = 'silver' WHERE `name_en` = 'Silver Cars Package';
UPDATE `plans` SET `badge` = 'bronze' WHERE `name_en` = 'Bronze Cars Package';

-- CMS Pages
INSERT INTO `cms_pages` (`slug`, `title_ar`, `title_en`, `title_he`, `content_ar`, `content_en`, `content_he`) VALUES
('privacy', 'سياسة الخصوصية', 'Privacy Policy', 'מדיניות פרטיות', '<h1>سياسة الخصوصية</h1><p>محتوى سياسة الخصوصية...</p>', '<h1>Privacy Policy</h1><p>Privacy policy content...</p>', '<h1>מדיניות פרטיות</h1><p>תוכן מדיניות הפרטיות...</p>'),
('terms', 'الشروط والأحكام', 'Terms & Conditions', 'תנאים והגבלות', '<h1>الشروط والأحكام</h1><p>محتوى الشروط والأحكام...</p>', '<h1>Terms & Conditions</h1><p>Terms and conditions content...</p>', '<h1>תנאים והגבלות</h1><p>תוכן התנאים וההגבלות...</p>'),
('disclaimer', 'إخلاء المسؤولية', 'Disclaimer', 'כתב ויתור', '<h1>إخلاء المسؤولية</h1><p>Rento Go منصة إعلانية فقط ولا تتدخل في العقود أو المدفوعات بين الأطراف...</p>', '<h1>Disclaimer</h1><p>Rento Go is an advertising platform only and does not intervene in contracts or payments between parties...</p>', '<h1>כתב ויתור</h1><p>Rento Go היא פלטפורמת פרסום בלבד ואינה מתערבת בחוזים או תשלומים בין הצדדים...</p>');

SET FOREIGN_KEY_CHECKS = 1;
