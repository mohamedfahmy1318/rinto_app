<?php
/**
 * Plan Controller
 */

class PlanController {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function index($input) {
        $category = $input['category'] ?? null;
        $propertyType = $input['property_type'] ?? null;
        $carUsageType = $input['car_usage_type'] ?? null;
        
        $where = "is_active = 1 AND (is_welcome_bonus = 0 OR is_welcome_bonus IS NULL)";
        $params = [];
        
        if ($category && in_array($category, ['properties', 'cars'])) {
            $where .= " AND category = ?";
            $params[] = $category;
        }
        
        // Filter by specific type: show matching plans OR general plans (null type)
        if ($propertyType && $category === 'properties') {
            $where .= " AND (property_type = ? OR property_type IS NULL)";
            $params[] = $propertyType;
        }
        
        if ($carUsageType && $category === 'cars') {
            $where .= " AND (car_usage_type = ? OR car_usage_type IS NULL)";
            $params[] = $carUsageType;
        }
        
        $sql = "SELECT * FROM plans WHERE $where ORDER BY category, sort_order, price";
        $plans = $this->db->fetchAll($sql, $params);
        
        // Group by category
        $grouped = [
            'properties' => [],
            'cars' => []
        ];
        
        foreach ($plans as $plan) {
            $plan['has_discount'] = !empty($plan['original_price']) && $plan['original_price'] > $plan['price'];
            $grouped[$plan['category']][] = $plan;
        }
        
        if ($category) {
            Response::success($grouped[$category]);
        } else {
            Response::success($grouped);
        }
    }
    
    public function show($id) {
        $plan = $this->db->fetch("SELECT * FROM plans WHERE id = ? AND is_active = 1", [$id]);
        
        if (!$plan) {
            Response::notFound('Plan not found');
        }
        
        $plan['has_discount'] = !empty($plan['original_price']) && $plan['original_price'] > $plan['price'];
        
        Response::success($plan);
    }
}
