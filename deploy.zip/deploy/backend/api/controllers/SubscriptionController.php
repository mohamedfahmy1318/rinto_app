<?php
/**
 * Subscription Controller
 */

class SubscriptionController {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function mySubscriptions($input) {
        $auth = JWT::authenticate();
        if (!$auth) {
            Response::unauthorized();
        }
        
        $status = $input['status'] ?? 'active';
        
        $where = "s.user_id = ?";
        $params = [$auth['user_id']];
        
        if ($status !== 'all') {
            if ($status === 'active') {
                $where .= " AND s.status = 'active' AND s.expires_at > NOW()";
            } else {
                $where .= " AND (s.status = ? OR s.expires_at <= NOW())";
                $params[] = $status;
            }
        }
        
        $sql = "SELECT s.*, 
                       p.name_ar as plan_name_ar, p.name_en as plan_name_en, p.name_he as plan_name_he,
                       p.category, p.plan_type, p.badge,
                       (SELECT COUNT(*) FROM properties WHERE subscription_id = s.id) as properties_count,
                       (SELECT COUNT(*) FROM cars WHERE subscription_id = s.id) as cars_count
                FROM subscriptions s
                LEFT JOIN plans p ON s.plan_id = p.id
                WHERE $where
                ORDER BY s.created_at DESC";
        
        $subscriptions = $this->db->fetchAll($sql, $params);
        
        foreach ($subscriptions as &$sub) {
            $sub['is_expired'] = strtotime($sub['expires_at']) < time();
            $sub['days_remaining'] = max(0, (int)((strtotime($sub['expires_at']) - time()) / 86400));
            
            if ($sub['is_unlimited']) {
                $sub['listings_remaining'] = 'unlimited';
            } else {
                $sub['listings_remaining'] = max(0, ($sub['listings_limit'] ?? 0) - ($sub['listings_used'] ?? 0));
            }
        }
        
        Response::success($subscriptions);
    }
    
    public function index($input) {
        return $this->mySubscriptions($input);
    }
    
    /**
     * Request a subscription plan (user requests, admin approves)
     */
    public function requestPlan($input) {
        $auth = JWT::authenticate();
        if (!$auth) {
            Response::unauthorized();
        }
        
        $planId = $input['plan_id'] ?? null;
        if (!$planId) {
            Response::error('Plan ID is required', 400);
        }
        
        // Check if plan exists and is active
        $plan = $this->db->fetch("SELECT * FROM plans WHERE id = ? AND is_active = 1", [$planId]);
        if (!$plan) {
            Response::notFound('Plan not found');
        }
        
        // Check if user already has a pending request for this exact plan
        $existingRequest = $this->db->fetch(
            "SELECT sr.* FROM subscription_requests sr 
             WHERE sr.user_id = ? AND sr.status = 'pending' AND sr.plan_id = ?",
            [$auth['user_id'], $planId]
        );
        
        if ($existingRequest) {
            Response::error('You already have a pending request for this plan', 400);
        }
        
        // Create subscription request
        $requestId = $this->db->insert('subscription_requests', [
            'user_id' => $auth['user_id'],
            'plan_id' => $planId
        ]);
        
        Response::success([
            'id' => $requestId,
            'message' => 'Subscription request submitted successfully. Waiting for admin approval.'
        ], 201);
    }
    
    /**
     * Get user's subscription requests
     */
    public function myRequests($input) {
        $auth = JWT::authenticate();
        if (!$auth) {
            Response::unauthorized();
        }
        
        $sql = "SELECT sr.*, 
                       p.name_ar as plan_name_ar, p.name_en as plan_name_en, p.name_he as plan_name_he,
                       p.category, p.plan_type, p.price, p.listings_count, p.is_unlimited, p.duration_days, p.badge
                FROM subscription_requests sr
                JOIN plans p ON sr.plan_id = p.id
                WHERE sr.user_id = ?
                ORDER BY sr.created_at DESC";
        
        $requests = $this->db->fetchAll($sql, [$auth['user_id']]);
        
        Response::success($requests);
    }
    
    /**
     * Cancel a pending subscription request
     */
    public function cancelRequest($id) {
        $auth = JWT::authenticate();
        if (!$auth) {
            Response::unauthorized();
        }
        
        $request = $this->db->fetch(
            "SELECT * FROM subscription_requests WHERE id = ? AND user_id = ?",
            [$id, $auth['user_id']]
        );
        
        if (!$request) {
            Response::notFound('Request not found');
        }
        
        if ($request['status'] !== 'pending') {
            Response::error('Only pending requests can be cancelled', 400);
        }
        
        $this->db->delete('subscription_requests', 'id = ?', [$id]);
        
        Response::success(['message' => 'Request cancelled successfully']);
    }
    
    /**
     * Check if user can add a listing (has active subscription with remaining slots)
     */
    public function canAddListing($input) {
        $auth = JWT::authenticate();
        if (!$auth) {
            Response::unauthorized();
        }
        
        $category = $input['category'] ?? null;
        if (!$category || !in_array($category, ['properties', 'cars'])) {
            Response::error('Valid category (properties/cars) is required', 400);
        }
        
        $result = $this->checkUserCanAddListing($auth['user_id'], $category);
        
        Response::success($result);
    }
    
    /**
     * Get active subscription for a category
     */
    public function getActiveSubscription($input) {
        $auth = JWT::authenticate();
        if (!$auth) {
            Response::unauthorized();
        }
        
        $category = $input['category'] ?? null;
        if (!$category || !in_array($category, ['properties', 'cars'])) {
            Response::error('Valid category (properties/cars) is required', 400);
        }
        
        $subscription = $this->getActiveSubscriptionForUser($auth['user_id'], $category);
        
        if ($subscription) {
            Response::success($subscription);
        } else {
            Response::success(null);
        }
    }
    
    /**
     * Helper: Check if user can add listing
     * Supports both old ENUM types (property_type, car_usage_type) and new dynamic type IDs (property_type_id, car_type_id)
     */
    public static function checkUserCanAddListing($userId, $category, $subType = null) {
        $db = Database::getInstance();
        
        // $subType can be a slug (e.g., 'apartment') for dynamic types
        // First, try to resolve the type to an ID if dynamic types table exists
        $typeId = null;
        if ($subType) {
            $typeTable = ($category === 'properties') ? 'property_types' : 'car_types';
            $typeRecord = $db->fetch("SELECT id FROM $typeTable WHERE slug = ? LIMIT 1", [$subType]);
            if ($typeRecord) {
                $typeId = $typeRecord['id'];
            }
        }
        
        // Get active subscription for this category and type
        // Priority: exact type match (by ID or slug) > null type (general) > any match
        $subscription = $db->fetch(
            "SELECT s.*, p.name_ar, p.name_en, p.name_he, p.category as plan_category, p.badge,
                    p.property_type, p.car_usage_type, p.property_type_id, p.car_type_id
             FROM subscriptions s
             JOIN plans p ON s.plan_id = p.id
             WHERE s.user_id = ? 
               AND (p.category = ? OR p.category IS NULL OR s.category = ? OR s.category IS NULL)
               AND s.status = 'active' 
               AND s.expires_at > NOW()
             ORDER BY 
                CASE 
                    WHEN (? = 'properties' AND (p.property_type = ? OR p.property_type_id = ?)) THEN 0
                    WHEN (? = 'cars' AND (p.car_usage_type = ? OR p.car_type_id = ?)) THEN 0
                    WHEN (p.property_type IS NULL AND p.car_usage_type IS NULL AND p.property_type_id IS NULL AND p.car_type_id IS NULL) THEN 1
                    ELSE 2 
                END,
                CASE WHEN p.category = ? THEN 0 ELSE 1 END,
                s.created_at DESC
             LIMIT 1",
            [$userId, $category, $category, $category, $subType, $typeId, $category, $subType, $typeId, $category]
        );
        
        // If subscription has specific type, verify it matches (supports both ENUM and dynamic ID)
        if ($subscription && $subType) {
            $planTypeSlug = ($category === 'properties') ? $subscription['property_type'] : $subscription['car_usage_type'];
            $planTypeId = ($category === 'properties') ? $subscription['property_type_id'] : $subscription['car_type_id'];
            
            $typeMatches = ($planTypeSlug === $subType) || ($planTypeId !== null && $planTypeId == $typeId);
            $isGeneral = ($planTypeSlug === null && $planTypeId === null);
            
            if (!$isGeneral && !$typeMatches) {
                // This subscription is for a different type, look for a general one
                $generalSub = $db->fetch(
                    "SELECT s.*, p.name_ar, p.name_en, p.name_he, p.category as plan_category, p.badge,
                            p.property_type, p.car_usage_type, p.property_type_id, p.car_type_id
                     FROM subscriptions s
                     JOIN plans p ON s.plan_id = p.id
                     WHERE s.user_id = ? 
                       AND p.category = ?
                       AND (
                           (p.property_type IS NULL AND p.property_type_id IS NULL) 
                           OR p.property_type = ? 
                           OR p.property_type_id = ?
                       )
                       AND (
                           (p.car_usage_type IS NULL AND p.car_type_id IS NULL) 
                           OR p.car_usage_type = ? 
                           OR p.car_type_id = ?
                       )
                       AND s.status = 'active' 
                       AND s.expires_at > NOW()
                       AND (s.is_unlimited = 1 OR s.listings_used < s.listings_limit)
                     ORDER BY s.created_at DESC
                     LIMIT 1",
                    [$userId, $category, $subType, $typeId, $subType, $typeId]
                );
                if ($generalSub) {
                    $subscription = $generalSub;
                } else {
                    return [
                        'can_add' => false,
                        'reason' => 'wrong_type',
                        'message_ar' => 'باقتك الحالية لا تشمل هذا النوع من الإعلانات.',
                        'message_en' => 'Your current subscription does not cover this listing type.',
                        'message_he' => 'המנוי הנוכחי שלך אינו מכסה סוג מודעה זה.',
                        'subscription' => null
                    ];
                }
            }
        }
        
        if (!$subscription) {
            return [
                'can_add' => false,
                'reason' => 'no_subscription',
                'message_ar' => 'ليس لديك اشتراك فعال. يرجى طلب باقة أولاً.',
                'message_en' => 'You do not have an active subscription. Please request a package first.',
                'message_he' => 'אין לך מנוי פעיל. אנא בקש חבילה קודם.',
                'subscription' => null
            ];
        }
        
        // Check if unlimited
        if ($subscription['is_unlimited']) {
            return [
                'can_add' => true,
                'reason' => 'unlimited',
                'listings_remaining' => 'unlimited',
                'subscription' => $subscription
            ];
        }
        
        // Check remaining listings
        $remaining = ($subscription['listings_limit'] ?? 0) - ($subscription['listings_used'] ?? 0);
        
        if ($remaining <= 0) {
            return [
                'can_add' => false,
                'reason' => 'limit_reached',
                'message_ar' => 'لقد استنفدت عدد الإعلانات المسموح في باقتك.',
                'message_en' => 'You have reached your listing limit.',
                'message_he' => 'הגעת למגבלת המודעות שלך.',
                'listings_remaining' => 0,
                'subscription' => $subscription
            ];
        }
        
        return [
            'can_add' => true,
            'reason' => 'has_slots',
            'listings_remaining' => $remaining,
            'subscription' => $subscription
        ];
    }
    
    /**
     * Helper: Get active subscription for user
     */
    public static function getActiveSubscriptionForUser($userId, $category) {
        $db = Database::getInstance();
        
        return $db->fetch(
            "SELECT s.*, p.name_ar, p.name_en, p.name_he, p.category as plan_category, p.badge, p.listings_count, p.is_unlimited as plan_unlimited
             FROM subscriptions s
             JOIN plans p ON s.plan_id = p.id
             WHERE s.user_id = ? 
               AND (p.category = ? OR p.category IS NULL OR s.category = ? OR s.category IS NULL)
               AND s.status = 'active' 
               AND s.expires_at > NOW()
             ORDER BY 
                CASE WHEN p.category = ? THEN 0 ELSE 1 END,
                s.created_at DESC
             LIMIT 1",
            [$userId, $category, $category, $category]
        );
    }
    
    /**
     * Helper: Increment listings used count
     */
    public static function incrementListingsUsed($subscriptionId) {
        $db = Database::getInstance();
        $db->query("UPDATE subscriptions SET listings_used = listings_used + 1 WHERE id = ?", [$subscriptionId]);
    }
    
    /**
     * Purchase a subscription (direct payment - Google Pay / Apple Pay)
     * TODO: Integrate real payment gateways
     */
    public function purchase($input) {
        $auth = JWT::authenticate();
        if (!$auth) {
            Response::unauthorized();
        }
        
        $planId = $input['plan_id'] ?? null;
        $paymentMethod = $input['payment_method'] ?? 'test_payment';
        $status = $input['status'] ?? 'active';
        
        // Bank transfer details
        $senderName = $input['sender_name'] ?? null;
        $transferDate = $input['transfer_date'] ?? null;
        $transferReference = $input['transfer_reference'] ?? null;
        
        if (!$planId) {
            Response::error('Plan ID is required', 400);
        }
        
        // Check if plan exists and is active
        $plan = $this->db->fetch("SELECT * FROM plans WHERE id = ? AND is_active = 1", [$planId]);
        if (!$plan) {
            Response::notFound('Plan not found');
        }
        
        // Prevent purchasing welcome bonus plans
        if (!empty($plan['is_welcome_bonus'])) {
            Response::error('This plan is not available for purchase', 400);
        }
        
        // All purchases require admin approval (except test mode)
        $isTestPayment = ($paymentMethod === 'test' || $paymentMethod === 'test_payment');
        $subscriptionStatus = $isTestPayment ? 'active' : 'pending_verification';
        $paymentStatus = $isTestPayment ? 'completed' : 'pending';
        
        // Check if user already has an active subscription for this category
        $existingSub = $this->getActiveSubscriptionForUser($auth['user_id'], $plan['category']);
        
        // Calculate expiry date
        $durationDays = $plan['duration_days'] ?? 30;
        $expiresAt = date('Y-m-d H:i:s', strtotime("+$durationDays days"));
        
        // If there's an existing subscription, extend it
        if ($existingSub) {
            // Add more listings to existing subscription
            $newLimit = $existingSub['listings_limit'] + ($plan['listings_count'] ?? 0);
            $newExpiry = max(strtotime($existingSub['expires_at']), strtotime($expiresAt));
            
            $this->db->query(
                "UPDATE subscriptions SET 
                    listings_limit = ?, 
                    expires_at = ?,
                    is_unlimited = ?
                 WHERE id = ?",
                [
                    $plan['is_unlimited'] ? 999999 : $newLimit,
                    date('Y-m-d H:i:s', $newExpiry),
                    $plan['is_unlimited'] ? 1 : $existingSub['is_unlimited'],
                    $existingSub['id']
                ]
            );
            
            $subscriptionId = $existingSub['id'];
        } else {
            // Create new subscription
            $subscriptionId = $this->db->insert('subscriptions', [
                'user_id' => $auth['user_id'],
                'plan_id' => $planId,
                'category' => $plan['category'],
                'status' => $subscriptionStatus,
                'listings_limit' => $plan['is_unlimited'] ? 999999 : ($plan['listings_count'] ?? 1),
                'listings_used' => 0,
                'is_unlimited' => $plan['is_unlimited'] ? 1 : 0,
                'expires_at' => $expiresAt,
                'payment_method' => $paymentMethod,
                'payment_reference' => $transferReference ?: (strtoupper($paymentMethod) . '_' . time() . '_' . $auth['user_id'])
            ]);
        }
        
        // Log the payment
        $platform = $input['platform'] ?? 'web';
        $transactionId = $input['transaction_id'] ?? (strtoupper($paymentMethod) . '_' . uniqid());
        
        $paymentData = [
            'user_id' => $auth['user_id'],
            'subscription_id' => $subscriptionId,
            'plan_id' => $planId,
            'amount' => $plan['price'] ?? 0,
            'currency' => 'ILS',
            'platform' => $platform,
            'payment_method' => $paymentMethod,
            'status' => $paymentStatus,
            'transaction_id' => $transactionId
        ];
        
        // Add bank transfer details if applicable
        if ($paymentMethod === 'bank_transfer') {
            $paymentData['sender_name'] = $senderName;
            $paymentData['transfer_date'] = $transferDate;
            $paymentData['notes'] = $transferReference ? "Reference: $transferReference" : null;
        }
        
        $this->db->insert('payments', $paymentData);
        
        $message = ($paymentMethod === 'bank_transfer') 
            ? 'Bank transfer submitted. Pending verification.'
            : 'Subscription activated successfully';
        
        Response::success([
            'subscription_id' => $subscriptionId,
            'message' => $message,
            'status' => $subscriptionStatus,
            'expires_at' => $expiresAt
        ], 201);
    }
    
    /**
     * Get available subscriptions for adding a listing
     * Returns: free bonus (if unused), active subscriptions matching the listing type, and available plans to buy
     */
    public function availableForListing($input) {
        $auth = JWT::authenticate();
        if (!$auth) {
            Response::unauthorized();
        }
        
        $category = $input['category'] ?? null; // properties or cars
        $subType = $input['sub_type'] ?? null; // property_type or car_usage_type
        
        if (!$category || !in_array($category, ['properties', 'cars'])) {
            Response::error('Category is required (properties or cars)', 400);
        }
        
        $result = [
            'free_bonus' => null,
            'active_subscriptions' => [],
            'available_plans' => []
        ];
        
        // Resolve subType to ID if using dynamic types
        $typeId = null;
        if ($subType) {
            $typeTable = ($category === 'properties') ? 'property_types' : 'car_types';
            $typeRecord = $this->db->fetch("SELECT id FROM $typeTable WHERE slug = ? LIMIT 1", [$subType]);
            if ($typeRecord) {
                $typeId = $typeRecord['id'];
            }
        }
        
        // 1. Check for unused free welcome bonus
        $freeBonus = $this->db->fetch(
            "SELECT s.*, p.name_ar, p.name_en, p.name_he, p.category, p.property_type, p.car_usage_type, p.property_type_id, p.car_type_id
             FROM subscriptions s
             JOIN plans p ON s.plan_id = p.id
             WHERE s.user_id = ? 
               AND p.is_welcome_bonus = 1
               AND s.status = 'active'
               AND s.expires_at > NOW()
               AND (s.is_unlimited = 1 OR s.listings_used < s.listings_limit)
               AND (p.category = ? OR p.category IS NULL)
             LIMIT 1",
            [$auth['user_id'], $category]
        );
        
        if ($freeBonus) {
            // Check if subtype matches (supports both ENUM and dynamic ID)
            $typeField = ($category === 'properties') ? 'property_type' : 'car_usage_type';
            $typeIdField = ($category === 'properties') ? 'property_type_id' : 'car_type_id';
            $planTypeSlug = $freeBonus[$typeField];
            $planTypeId = $freeBonus[$typeIdField];
            
            $isGeneral = ($planTypeSlug === null && $planTypeId === null);
            $typeMatches = ($planTypeSlug === $subType) || ($planTypeId !== null && $planTypeId == $typeId);
            
            if ($isGeneral || $typeMatches || $subType === null) {
                $freeBonus['listings_remaining'] = $freeBonus['is_unlimited'] 
                    ? 'unlimited' 
                    : max(0, ($freeBonus['listings_limit'] ?? 0) - ($freeBonus['listings_used'] ?? 0));
                $result['free_bonus'] = $freeBonus;
            }
        }
        
        // 2. Get active subscriptions matching category and type (excluding free bonus)
        // Supports both old ENUM and new dynamic type IDs
        $typeCondition = "";
        $params = [$auth['user_id'], $category];
        
        if ($subType) {
            if ($category === 'properties') {
                $typeCondition = " AND (p.property_type = ? OR p.property_type IS NULL OR p.property_type_id = ? OR p.property_type_id IS NULL)";
                $params[] = $subType;
                $params[] = $typeId;
            } else {
                $typeCondition = " AND (p.car_usage_type = ? OR p.car_usage_type IS NULL OR p.car_type_id = ? OR p.car_type_id IS NULL)";
                $params[] = $subType;
                $params[] = $typeId;
            }
        }
        
        $activeSubscriptions = $this->db->fetchAll(
            "SELECT s.*, p.name_ar, p.name_en, p.name_he, p.category, p.property_type, p.car_usage_type, p.property_type_id, p.car_type_id, p.badge
             FROM subscriptions s
             JOIN plans p ON s.plan_id = p.id
             WHERE s.user_id = ? 
               AND p.category = ?
               AND (p.is_welcome_bonus = 0 OR p.is_welcome_bonus IS NULL)
               AND s.status = 'active'
               AND s.expires_at > NOW()
               AND (s.is_unlimited = 1 OR s.listings_used < s.listings_limit)
               $typeCondition
             ORDER BY s.created_at DESC",
            $params
        );
        
        foreach ($activeSubscriptions as &$sub) {
            $sub['listings_remaining'] = $sub['is_unlimited'] 
                ? 'unlimited' 
                : max(0, ($sub['listings_limit'] ?? 0) - ($sub['listings_used'] ?? 0));
        }
        $result['active_subscriptions'] = $activeSubscriptions;
        
        // 3. Get available plans to purchase (matching category and type)
        // Supports both old ENUM and new dynamic type IDs
        $planParams = [$category];
        $planTypeCondition = "";
        
        if ($subType) {
            if ($category === 'properties') {
                $planTypeCondition = " AND (property_type = ? OR property_type IS NULL OR property_type_id = ? OR property_type_id IS NULL)";
                $planParams[] = $subType;
                $planParams[] = $typeId;
            } else {
                $planTypeCondition = " AND (car_usage_type = ? OR car_usage_type IS NULL OR car_type_id = ? OR car_type_id IS NULL)";
                $planParams[] = $subType;
                $planParams[] = $typeId;
            }
        }
        
        $availablePlans = $this->db->fetchAll(
            "SELECT * FROM plans 
             WHERE is_active = 1 
               AND (is_welcome_bonus = 0 OR is_welcome_bonus IS NULL)
               AND category = ?
               $planTypeCondition
             ORDER BY sort_order, price",
            $planParams
        );
        
        $result['available_plans'] = $availablePlans;
        
        Response::success($result);
    }
}
