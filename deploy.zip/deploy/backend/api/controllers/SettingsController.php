<?php
/**
 * Settings Controller - إعدادات التطبيق والشروط
 */

class SettingsController {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Get terms of service
     */
    public function terms($input) {
        $lang = $input['lang'] ?? 'ar';
        $setting = $this->getSetting('terms_of_service', $lang);
        
        Response::success([
            'content' => $setting,
            'type' => 'terms_of_service'
        ]);
    }
    
    /**
     * Get privacy policy
     */
    public function privacy($input) {
        $lang = $input['lang'] ?? 'ar';
        $setting = $this->getSetting('privacy_policy', $lang);
        
        Response::success([
            'content' => $setting,
            'type' => 'privacy_policy'
        ]);
    }
    
    /**
     * Get any setting by key
     */
    public function get($input) {
        $key = $input['key'] ?? null;
        $lang = $input['lang'] ?? 'ar';
        
        if (!$key) {
            Response::error('Setting key is required', 400);
        }
        
        $setting = $this->getSetting($key, $lang);
        
        if ($setting === null) {
            Response::notFound('Setting not found');
        }
        
        Response::success([
            'key' => $key,
            'content' => $setting
        ]);
    }
    
    /**
     * Helper to get setting value
     */
    private function getSetting($key, $lang = 'ar') {
        $column = 'value_' . $lang;
        if (!in_array($column, ['value_ar', 'value_en', 'value_he'])) {
            $column = 'value_ar';
        }
        
        $result = $this->db->fetch(
            "SELECT $column as value FROM app_settings WHERE setting_key = ?",
            [$key]
        );
        
        return $result ? $result['value'] : null;
    }
}
