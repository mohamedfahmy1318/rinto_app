<?php
/**
 * Banner Controller - For admin promotional banners
 */

class BannerController {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Get active banners for display
     */
    public function index($input) {
        $type = $input['type'] ?? null; // property, car, or null for all
        
        $where = "b.is_active = 1 AND (b.starts_at IS NULL OR b.starts_at <= NOW()) AND (b.ends_at IS NULL OR b.ends_at >= NOW())";
        $params = [];
        
        if ($type) {
            $where .= " AND b.banner_type = ?";
            $params[] = $type;
        }
        
        $sql = "SELECT b.*, 
                       r.name_ar as region_name_ar, r.name_en as region_name_en, r.name_he as region_name_he,
                       c.name_ar as city_name_ar, c.name_en as city_name_en, c.name_he as city_name_he
                FROM admin_banners b
                LEFT JOIN regions r ON b.region_id = r.id
                LEFT JOIN cities c ON b.city_id = c.id
                WHERE $where
                ORDER BY b.display_order ASC, b.created_at DESC
                LIMIT 10";
        
        $banners = $this->db->fetchAll($sql, $params);
        
        // Get media for each banner
        foreach ($banners as &$banner) {
            $media = $this->db->fetchAll(
                "SELECT id, media_type, file_path, sort_order FROM admin_banner_media WHERE banner_id = ? ORDER BY sort_order",
                [$banner['id']]
            );
            
            foreach ($media as &$m) {
                $m['url'] = UPLOAD_URL . $m['file_path'];
            }
            
            $banner['media'] = $media;
            
            // Set thumbnail
            if (empty($banner['thumbnail']) && !empty($media)) {
                $banner['thumbnail'] = UPLOAD_URL . $media[0]['file_path'];
            } elseif (!empty($banner['thumbnail'])) {
                $banner['thumbnail'] = UPLOAD_URL . $banner['thumbnail'];
            }
        }
        
        Response::success($banners);
    }
    
    /**
     * Get single banner details
     */
    public function show($id) {
        $sql = "SELECT b.*, 
                       r.name_ar as region_name_ar, r.name_en as region_name_en, r.name_he as region_name_he,
                       c.name_ar as city_name_ar, c.name_en as city_name_en, c.name_he as city_name_he
                FROM admin_banners b
                LEFT JOIN regions r ON b.region_id = r.id
                LEFT JOIN cities c ON b.city_id = c.id
                WHERE b.id = ?";
        
        $banner = $this->db->fetch($sql, [$id]);
        
        if (!$banner) {
            Response::notFound('Banner not found');
        }
        
        // Get media
        $media = $this->db->fetchAll(
            "SELECT id, media_type, file_path, sort_order FROM admin_banner_media WHERE banner_id = ? ORDER BY sort_order",
            [$id]
        );
        
        foreach ($media as &$m) {
            $m['url'] = UPLOAD_URL . $m['file_path'];
        }
        
        $banner['media'] = $media;
        
        // Set thumbnail
        if (empty($banner['thumbnail']) && !empty($media)) {
            $banner['thumbnail'] = UPLOAD_URL . $media[0]['file_path'];
        } elseif (!empty($banner['thumbnail'])) {
            $banner['thumbnail'] = UPLOAD_URL . $banner['thumbnail'];
        }
        
        // Increment views
        $this->db->query("UPDATE admin_banners SET views_count = views_count + 1 WHERE id = ?", [$id]);
        
        Response::success($banner);
    }
}
