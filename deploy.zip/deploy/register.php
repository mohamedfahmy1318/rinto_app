<?php
$pageTitle = 'إنشاء حساب';
require_once __DIR__ . '/config.php';

$error = '';
$success = '';

$userTypes = [
    'renter' => 'مستأجر',
    'owner' => 'مالك عقار',
    'office' => 'مكتب عقارات',
    'car_lessor' => 'مؤجر سيارات'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $userType = $_POST['user_type'] ?? 'renter';
    
    if ($password !== $confirmPassword) {
        $error = 'كلمتا المرور غير متطابقتين';
    } else {
        $response = apiCall('auth/register', 'POST', [
            'name' => $name,
            'phone' => $phone,
            'email' => $email,
            'password' => $password,
            'user_type' => $userType
        ]);
        
        if ($response['success'] ?? false) {
            $_SESSION['user'] = $response['data']['user'];
            $_SESSION['token'] = $response['data']['token'];
            header('Location: ' . SITE_URL);
            exit;
        } else {
            $error = $response['message'] ?? 'فشل إنشاء الحساب';
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="auth-page py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="auth-card">
                    <div class="text-center mb-4">
                        <i class="bi bi-person-plus-fill auth-icon"></i>
                        <h2>إنشاء حساب جديد</h2>
                        <p class="text-muted">أنشئ حسابك للبدء</p>
                    </div>
                    
                    <?php if ($error): ?>
                    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>
                    
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label class="form-label">الاسم الكامل</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-person"></i></span>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">رقم الهاتف</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-phone"></i></span>
                                <input type="tel" name="phone" class="form-control" dir="ltr" placeholder="+972501234567" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">البريد الإلكتروني (اختياري)</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                                <input type="email" name="email" class="form-control" dir="ltr">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">نوع الحساب</label>
                            <select name="user_type" class="form-select">
                                <?php foreach ($userTypes as $value => $label): ?>
                                <option value="<?= $value ?>"><?= $label ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">كلمة المرور</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                                    <input type="password" name="password" class="form-control" minlength="6" required>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">تأكيد كلمة المرور</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                                    <input type="password" name="confirm_password" class="form-control" minlength="6" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-check mb-4">
                            <input type="checkbox" class="form-check-input" id="terms" required>
                            <label class="form-check-label" for="terms">
                                أوافق على <a href="terms.php">الشروط والأحكام</a> و<a href="privacy.php">سياسة الخصوصية</a>
                            </label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100 btn-lg mb-3">
                            <i class="bi bi-person-plus me-2"></i>إنشاء الحساب
                        </button>
                        
                        <p class="text-center mb-0">
                            لديك حساب؟ <a href="login.php">تسجيل الدخول</a>
                        </p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
