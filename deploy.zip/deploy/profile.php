<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/translations.php';
$pageTitle = __('my_account');
$extraCss = ['assets/css/profile.css'];
$extraJs = ['assets/js/profile.js'];

// Check if logged in
if (!isset($_SESSION['user']) || !isset($_SESSION['token'])) {
    header('Location: login.php');
    exit;
}

$user = $_SESSION['user'];
$token = $_SESSION['token'];
$error = '';
$success = '';

// Handle logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    unset($_SESSION['user']);
    unset($_SESSION['token']);
    header('Location: ' . SITE_URL);
    exit;
}

// Fetch user's listings
function apiCallWithAuth($endpoint, $token) {
    $url = API_URL . '/' . ltrim($endpoint, '/');
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Accept: application/json',
        'Authorization: Bearer ' . $token
    ]);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return json_decode($response, true);
}

$myListings = apiCallWithAuth('me/listings', $token);
$listings = $myListings['data'] ?? [];

// Fetch user subscriptions
$subscriptionsResponse = apiCallWithAuth('subscriptions', $token);
$subscriptions = $subscriptionsResponse['data'] ?? [];

// Separate active subscriptions by category
$activeSubscriptions = [];
foreach ($subscriptions as $sub) {
    if (!($sub['is_expired'] ?? true) && ($sub['status'] ?? '') === 'active') {
        $category = $sub['category'] ?? 'properties';
        $activeSubscriptions[$category] = $sub;
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="profile-container">
    <div class="container">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-lg-4 mb-4">
                <div class="profile-sidebar">
                    <div class="text-center mb-4">
                        <div class="profile-avatar">
                            <?php if (!empty($user['profile_image'])): ?>
                            <img src="<?= UPLOAD_URL . $user['profile_image'] ?>" alt="">
                            <?php else: ?>
                            <i class="bi bi-person"></i>
                            <?php endif; ?>
                        </div>
                        <h4 class="profile-name"><?= htmlspecialchars($user['name'] ?? '') ?></h4>
                        <p class="profile-phone"><?= htmlspecialchars($user['phone'] ?? '') ?></p>
                        <?php if ($user['is_trusted'] ?? false): ?>
                        <span class="verified-badge"><i class="bi bi-patch-check-fill"></i><?= __('verified') ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="profile-nav">
                        <div class="list-group">
                            <a href="#profile" class="list-group-item list-group-item-action active" data-bs-toggle="list">
                                <i class="bi bi-person"></i><?= __('my_info') ?>
                            </a>
                            <a href="#subscriptions" class="list-group-item list-group-item-action" data-bs-toggle="list">
                                <i class="bi bi-box-seam"></i><?= __('my_subscriptions') ?>
                            </a>
                            <a href="#listings" class="list-group-item list-group-item-action" data-bs-toggle="list">
                                <i class="bi bi-grid-3x3-gap"></i><?= __('my_listings') ?>
                                <span class="listings-count"><?= count($listings) ?></span>
                            </a>
                            <a href="#favorites" class="list-group-item list-group-item-action" data-bs-toggle="list">
                                <i class="bi bi-heart"></i><?= __('favorites') ?>
                            </a>
                            <a href="#settings" class="list-group-item list-group-item-action" data-bs-toggle="list">
                                <i class="bi bi-gear"></i><?= __('settings') ?>
                            </a>
                            <a href="?action=logout" class="list-group-item list-group-item-action text-danger">
                                <i class="bi bi-box-arrow-left"></i><?= __('logout') ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Content -->
            <div class="col-lg-8">
                <div class="tab-content">
                    <!-- Profile Info -->
                    <div class="tab-pane fade show active" id="profile">
                        <div class="profile-card">
                            <h5><i class="bi bi-person-badge"></i><?= __('personal_info') ?></h5>
                            
                            <div class="info-grid mt-4">
                                <div class="info-item">
                                    <label><?= __('full_name') ?></label>
                                    <p><?= htmlspecialchars($user['name'] ?? '-') ?></p>
                                </div>
                                <div class="info-item">
                                    <label><?= __('account_type') ?></label>
                                    <p><?= __($user['user_type'] ?? 'renter') ?></p>
                                </div>
                                <div class="info-item">
                                    <label><?= __('phone') ?></label>
                                    <p dir="ltr"><?= htmlspecialchars($user['phone'] ?? '-') ?></p>
                                </div>
                                <div class="info-item">
                                    <label><?= __('email') ?></label>
                                    <p dir="ltr"><?= htmlspecialchars($user['email'] ?? '-') ?></p>
                                </div>
                                <div class="info-item">
                                    <label><?= __('registration_date') ?></label>
                                    <p><?= date('Y/m/d', strtotime($user['created_at'] ?? 'now')) ?></p>
                                </div>
                                <div class="info-item">
                                    <label><?= __('account_status') ?></label>
                                    <p><span class="badge bg-success"><?= __('active') ?></span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Subscriptions -->
                    <div class="tab-pane fade" id="subscriptions">
                        <div class="profile-card">
                            <h5><i class="bi bi-box-seam"></i><?= __('my_subscriptions') ?></h5>
                            
                            <?php if (empty($activeSubscriptions)): ?>
                            <div class="empty-state">
                                <div class="empty-state-icon">
                                    <i class="bi bi-box-seam"></i>
                                </div>
                                <h6><?= __('no_active_subscription') ?></h6>
                                <div class="mt-3">
                                    <a href="packages.php" class="btn btn-primary"><?= __('subscribe_now') ?></a>
                                </div>
                            </div>
                            <?php else: ?>
                            <div class="row g-3 mt-3">
                                <?php foreach ($activeSubscriptions as $category => $sub): 
                                    $planName = $sub['plan_name_' . $lang] ?? $sub['plan_name_ar'] ?? '';
                                    $listingsUsed = $sub['listings_used'] ?? 0;
                                    $listingsLimit = $sub['listings_limit'] ?? 0;
                                    $isUnlimited = $sub['is_unlimited'] ?? false;
                                    $listingsRemaining = $isUnlimited ? __('unlimited') : max(0, $listingsLimit - $listingsUsed);
                                    $daysRemaining = $sub['days_remaining'] ?? 0;
                                    $categoryLabel = $category === 'properties' ? __('properties_sub') : __('cars_sub');
                                ?>
                                <div class="col-md-6">
                                    <div class="subscription-card" style="background: linear-gradient(135deg, var(--teal) 0%, var(--teal-dark) 100%); border-radius: 15px; padding: 1.5rem; color: white;">
                                        <div class="d-flex align-items-center justify-content-between mb-3">
                                            <div class="d-flex align-items-center">
                                                <i class="bi bi-<?= $category === 'properties' ? 'building' : 'car-front' ?> fs-4 me-2"></i>
                                                <span class="fw-bold"><?= __('subscription_for') ?> <?= $categoryLabel ?></span>
                                            </div>
                                            <span class="badge bg-white text-success"><?= __('active') ?></span>
                                        </div>
                                        
                                        <h5 class="mb-3"><?= htmlspecialchars($planName) ?></h5>
                                        
                                        <div class="row text-center g-2">
                                            <div class="col-4">
                                                <div class="bg-white bg-opacity-25 rounded p-2">
                                                    <div class="fs-4 fw-bold"><?= $listingsUsed ?></div>
                                                    <small><?= __('listings_used') ?></small>
                                                </div>
                                            </div>
                                            <div class="col-4">
                                                <div class="bg-white bg-opacity-25 rounded p-2">
                                                    <div class="fs-4 fw-bold"><?= $isUnlimited ? '∞' : $listingsRemaining ?></div>
                                                    <small><?= __('listings_remaining') ?></small>
                                                </div>
                                            </div>
                                            <div class="col-4">
                                                <div class="bg-white bg-opacity-25 rounded p-2">
                                                    <div class="fs-4 fw-bold"><?= $daysRemaining ?></div>
                                                    <small><?= __('days') ?></small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            
                            <div class="mt-4 text-center">
                                <a href="packages.php" class="btn btn-outline-primary">
                                    <i class="bi bi-plus-circle me-2"></i><?= __('subscribe_now') ?>
                                </a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Listings -->
                    <div class="tab-pane fade" id="listings">
                        <div class="profile-card">
                            <div class="listings-header">
                                <h5><i class="bi bi-grid-3x3-gap"></i><?= __('my_listings') ?></h5>
                                <div class="d-flex gap-2">
                                    <a href="add-property.php" class="btn btn-primary btn-sm">
                                        <i class="bi bi-building-add me-1"></i><?= __('add_property') ?>
                                    </a>
                                    <a href="add-car.php" class="btn btn-primary btn-sm">
                                        <i class="bi bi-car-front-fill me-1"></i><?= __('add_car') ?>
                                    </a>
                                </div>
                            </div>
                            
                            <?php if (empty($listings)): ?>
                            <div class="empty-state">
                                <div class="empty-state-icon">
                                    <i class="bi bi-inbox"></i>
                                </div>
                                <h6><?= __('no_listings') ?></h6>
                                <p class="text-muted small"><?= $lang === 'he' ? 'הוסף את המודעה הראשונה שלך' : 'أضف إعلانك الأول' ?></p>
                            </div>
                            <?php else: ?>
                            <div class="listings-grid">
                                <?php foreach ($listings as $listing): ?>
                                <?php
                                $cityName = $listing['city_name_' . $lang] ?? $listing['city_name_ar'] ?? '';
                                ?>
                                <div class="listing-card-profile">
                                    <div class="card-img-wrapper">
                                        <img src="<?= htmlspecialchars($listing['thumbnail'] ?? UPLOAD_URL . 'placeholder.png') ?>" alt="">
                                        <div class="badges">
                                            <span class="badge badge-type">
                                                <i class="bi bi-<?= $listing['listing_type'] === 'property' ? 'building' : 'car-front' ?> me-1"></i>
                                                <?= __($listing['listing_type'] === 'property' ? 'property' : 'car') ?>
                                            </span>
                                            <span class="badge badge-status <?= $listing['status'] === 'active' ? 'active' : ($listing['status'] === 'pending_admin_review' ? 'pending' : '') ?>">
                                                <?php
                                                $statusKey = 'status_' . ($listing['status'] === 'pending_admin_review' ? 'pending' : $listing['status']);
                                                echo ($listing['status'] === 'active' ? '✓ ' : ($listing['status'] === 'pending_admin_review' ? '⏳ ' : ($listing['status'] === 'rejected' ? '✗ ' : '')));
                                                echo __($statusKey);
                                                ?>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <h6 class="listing-title"><?= htmlspecialchars($listing['title'] ?? __('no_title')) ?></h6>
                                        <p class="listing-location">
                                            <i class="bi bi-geo-alt-fill"></i>
                                            <?= htmlspecialchars($cityName) ?>
                                        </p>
                                        <p class="listing-price">
                                            <?php if ($listing['listing_type'] === 'car' && !empty($listing['price_daily'])): ?>
                                                <?= number_format($listing['price_daily']) ?> ₪ <small>/يومي</small>
                                            <?php else: ?>
                                                <?= number_format($listing['price'] ?? 0) ?> ₪
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <div class="card-footer">
                                        <a href="details.php?type=<?= $listing['listing_type'] ?>&id=<?= $listing['id'] ?>" class="btn-view">
                                            <i class="bi bi-eye me-1"></i><?= __('view') ?>
                                        </a>
                                        <a href="edit-listing.php?type=<?= $listing['listing_type'] ?>&id=<?= $listing['id'] ?>" class="btn-edit">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Favorites -->
                    <div class="tab-pane fade" id="favorites">
                        <div class="profile-card">
                            <h5><i class="bi bi-heart"></i><?= __('favorites') ?></h5>
                            <div class="empty-state">
                                <div class="empty-state-icon">
                                    <i class="bi bi-heart"></i>
                                </div>
                                <h6><?= __('no_favorites') ?></h6>
                                <div class="mt-3">
                                    <a href="properties.php" class="btn btn-outline-primary me-2"><?= __('browse_properties') ?></a>
                                    <a href="cars.php" class="btn btn-outline-primary"><?= __('browse_cars') ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Settings -->
                    <div class="tab-pane fade" id="settings">
                        <div class="profile-card">
                            <h5><i class="bi bi-gear"></i><?= __('settings') ?></h5>
                            
                            <div class="mt-4">
                                <div class="setting-item">
                                    <div>
                                        <h6><?= __('notifications') ?></h6>
                                        <small><?= __('receive_notifications') ?></small>
                                    </div>
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="notificationToggle" checked>
                                    </div>
                                </div>
                                
                                <div class="setting-item">
                                    <div>
                                        <h6><?= __('language') ?></h6>
                                        <small><?= __('display_language') ?></small>
                                    </div>
                                    <select class="form-select w-auto" id="languageSelect">
                                        <option value="ar" <?= ($lang ?? 'ar') === 'ar' ? 'selected' : '' ?>>العربية</option>
                                        <option value="he" <?= ($lang ?? 'ar') === 'he' ? 'selected' : '' ?>>עברית</option>
                                    </select>
                                </div>
                                
                                <div class="setting-item">
                                    <div>
                                        <h6><?= __('dark_mode') ?></h6>
                                        <small><?= __('enable_dark_mode') ?></small>
                                    </div>
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="darkModeToggle">
                                    </div>
                                </div>
                            </div>
                            
                            <hr class="my-4">
                            
                            <div class="d-flex gap-2">
                                <a href="?action=logout" class="btn btn-outline-danger">
                                    <i class="bi bi-box-arrow-left me-2"></i><?= __('logout') ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
